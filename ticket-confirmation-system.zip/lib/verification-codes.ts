// Utility functions for verification codes
export function generateVerificationCode(name: string, amount: number, index: number): string {
  // Get first 3 letters of name (uppercase)
  const namePrefix = name
    .replace(/[^a-zA-Z]/g, "")
    .substring(0, 3)
    .toUpperCase()
    .padEnd(3, "X")

  // Generate sequence number based on current timestamp and index for uniqueness
  const timestamp = Date.now().toString().slice(-3)
  const sequence = String(index + 1).padStart(3, "0")
  const uniqueSequence = `${sequence}${timestamp.slice(-1)}`

  // Determine ticket type suffix
  let typeSuffix = "REG"
  if (amount === 5000) typeSuffix = "VIP"
  else if (amount === 10000) typeSuffix = "VVIP"
  else if (amount > 3000 && amount < 5000) typeSuffix = "VIP"
  else if (amount > 10000) typeSuffix = "VVIP"

  return `${namePrefix}-${uniqueSequence.slice(0, 3)}-${typeSuffix}`
}

export function ensureUniqueCode(code: string, existingCodes: string[]): string {
  let uniqueCode = code
  let counter = 1

  while (existingCodes.includes(uniqueCode)) {
    // Add a suffix to make it unique
    const parts = code.split("-")
    if (parts.length === 3) {
      uniqueCode = `${parts[0]}-${parts[1]}${counter}-${parts[2]}`
    } else {
      uniqueCode = `${code}-${counter}`
    }
    counter++
  }

  return uniqueCode
}

// Function to generate code for existing names without codes
export function generateCodeForExistingName(name: string, amount: number, existingCodes: string[]): string {
  const baseCode = generateVerificationCode(name, amount, existingCodes.length)
  return ensureUniqueCode(baseCode, existingCodes)
}
