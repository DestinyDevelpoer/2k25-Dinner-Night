-- First, add the verification_code column if it doesn't exist
ALTER TABLE paid_names ADD COLUMN IF NOT EXISTS verification_code TEXT UNIQUE;

-- Update all existing names without verification codes
UPDATE paid_names 
SET verification_code = CONCAT(
  UPPER(SUBSTRING(name, 1, 3)),
  '-',
  LPAD((ROW_NUMBER() OVER (ORDER BY created_at))::text, 3, '0'),
  '-',
  CASE 
    WHEN amount_paid <= 3000 THEN 'REG'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVI'
    ELSE 'REG'
  END
)
WHERE verification_code IS NULL OR verification_code = '';

-- Ensure all codes are unique by adding a suffix if needed
WITH duplicate_codes AS (
  SELECT verification_code, COUNT(*) as count
  FROM paid_names 
  WHERE verification_code IS NOT NULL
  GROUP BY verification_code
  HAVING COUNT(*) > 1
)
UPDATE paid_names 
SET verification_code = verification_code || '-' || id::text
WHERE verification_code IN (SELECT verification_code FROM duplicate_codes);

-- Show all verification codes
SELECT name, amount_paid, verification_code,
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
  END as ticket_type
FROM paid_names 
ORDER BY amount_paid, name;
