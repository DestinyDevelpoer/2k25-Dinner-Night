-- Update the function to use VVIP instead of VVI
CREATE OR REPLACE FUNCTION generate_verification_code_for_new_name()
RETURNS TRIGGER AS $$
DECLARE
  name_prefix TEXT;
  type_suffix TEXT;
  sequence_num TEXT;
  new_code TEXT;
  existing_codes TEXT[];
  counter INTEGER := 1;
BEGIN
  -- Only generate if verification_code is NULL or empty
  IF NEW.verification_code IS NULL OR NEW.verification_code = '' THEN
    -- Get existing codes to ensure uniqueness
    SELECT ARRAY(SELECT verification_code FROM paid_names WHERE verification_code IS NOT NULL AND verification_code != '') 
    INTO existing_codes;
    
    -- Generate name prefix (first 3 letters, uppercase)
    name_prefix := UPPER(SUBSTRING(REGEXP_REPLACE(NEW.name, '[^a-zA-Z]', '', 'g'), 1, 3));
    IF LENGTH(name_prefix) < 3 THEN
      name_prefix := RPAD(name_prefix, 3, 'X');
    END IF;
    
    -- Determine ticket type suffix based on amount (updated to use VVIP)
    IF NEW.amount_paid = 5000 THEN
      type_suffix := 'VIP';
    ELSIF NEW.amount_paid = 10000 THEN
      type_suffix := 'VVIP';
    ELSIF NEW.amount_paid > 3000 AND NEW.amount_paid < 5000 THEN
      type_suffix := 'VIP';
    ELSIF NEW.amount_paid > 10000 THEN
      type_suffix := 'VVIP';
    ELSE
      type_suffix := 'REG';
    END IF;
    
    -- Generate sequence number (3 digits)
    sequence_num := LPAD((ARRAY_LENGTH(existing_codes, 1) + 1)::TEXT, 3, '0');
    
    -- Create the verification code
    new_code := name_prefix || '-' || sequence_num || '-' || type_suffix;
    
    -- Ensure uniqueness by adding counter if needed
    WHILE new_code = ANY(existing_codes) LOOP
      new_code := name_prefix || '-' || sequence_num || counter::TEXT || '-' || type_suffix;
      counter := counter + 1;
    END LOOP;
    
    -- Set the generated code
    NEW.verification_code := new_code;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update existing codes that use VVI to VVIP
UPDATE paid_names 
SET verification_code = REPLACE(verification_code, '-VVI', '-VVIP')
WHERE verification_code LIKE '%-VVI';

-- Update existing codes that use VVI at the end
UPDATE paid_names 
SET verification_code = REPLACE(verification_code, 'VVI', 'VVIP')
WHERE verification_code ~ 'VVI$';

-- Show updated results
SELECT name, amount_paid, verification_code,
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
    ELSE 'Regular'
  END as ticket_type
FROM paid_names 
ORDER BY amount_paid, name;

-- Verify the changes
SELECT 
  CASE 
    WHEN verification_code LIKE '%-REG' THEN 'Regular'
    WHEN verification_code LIKE '%-VIP' THEN 'VIP'
    WHEN verification_code LIKE '%-VVIP' THEN 'VVIP'
    ELSE 'Other'
  END as code_type,
  COUNT(*) as count
FROM paid_names 
WHERE verification_code IS NOT NULL
GROUP BY 
  CASE 
    WHEN verification_code LIKE '%-REG' THEN 'Regular'
    WHEN verification_code LIKE '%-VIP' THEN 'VIP'
    WHEN verification_code LIKE '%-VVIP' THEN 'VVIP'
    ELSE 'Other'
  END
ORDER BY count DESC;
