-- Add verification codes to all existing paid names
UPDATE paid_names 
SET verification_code = CONCAT(
  UPPER(SUBSTRING(MD5(RANDOM()::text), 1, 3)),
  '-',
  UPPER(SUBSTRING(MD5(RANDOM()::text), 1, 3)),
  '-',
  UPPER(SUBSTRING(MD5(RANDOM()::text), 1, 3))
)
WHERE verification_code IS NULL;

-- Add verification_code column if it doesn't exist
ALTER TABLE paid_names ADD COLUMN IF NOT EXISTS verification_code TEXT UNIQUE;

-- Update the paid_names table with unique codes for each person
UPDATE paid_names SET verification_code = 
  CASE name
    -- Regular Tickets
    WHEN 'Prudence' THEN 'PRU-001-REG'
    WHEN 'Sule Glory Lukman' THEN 'SUL-002-REG'
    WHEN 'Oluwatoyin' THEN 'OLU-003-REG'
    WHEN 'Louisa' THEN 'LOU-004-REG'
    WHEN 'Ifun' THEN 'IFU-005-REG'
    WHEN 'Faith Oseriemen' THEN 'FAI-006-REG'
    WHEN 'Idris Miriam' THEN 'IDR-007-REG'
    WHEN 'Halima' THEN 'HAL-008-REG'
    WHEN 'Fauza' THEN 'FAU-009-REG'
    WHEN 'Farida' THEN 'FAR-010-REG'
    WHEN 'Best' THEN 'BES-011-REG'
    WHEN 'Ryce' THEN 'RYC-012-REG'
    WHEN 'Favour Osehi' THEN 'FAV-013-REG'
    WHEN 'Cherish' THEN 'CHE-014-REG'
    WHEN 'Grace Onostate' THEN 'GRA-015-REG'
    WHEN 'Bernice' THEN 'BER-016-REG'
    WHEN 'Esther' THEN 'EST-017-REG'
    WHEN 'Olaye Victory' THEN 'OLA-018-REG'
    
    -- VIP Tickets
    WHEN 'Aitoye Orime' THEN 'AIT-001-VIP'
    WHEN 'Odim Gift' THEN 'ODI-002-VIP'
    WHEN 'Augustina Agbaye' THEN 'AUG-003-VIP'
    WHEN 'Adsuwa Slyvia Oshio' THEN 'ADS-004-VIP'
    WHEN 'Aikhomu Michael P.' THEN 'AIK-005-VIP'
    WHEN 'Testimony Ejohi A.' THEN 'TES-006-VIP'
    WHEN 'Blessing Precious M.' THEN 'BLE-007-VIP'
    WHEN 'Destiny Oche' THEN 'DES-008-VIP'
    WHEN 'Victoria Verekee' THEN 'VIC-009-VIP'
    WHEN 'Lucia' THEN 'LUC-010-VIP'
    WHEN 'Steven Francesca Ikhai Alasa' THEN 'STE-011-VIP'
    WHEN 'Sado Sweet' THEN 'SAD-012-VIP'
    WHEN 'Eze Chidera' THEN 'EZE-013-VIP'
    WHEN 'Udegbe Ose' THEN 'UDE-014-VIP'
    WHEN 'Precious Ethis' THEN 'PRE-015-VIP'
    WHEN 'Bella' THEN 'BEL-016-VIP'
    WHEN 'Agape Peter' THEN 'AGA-017-VIP'
    WHEN 'Jessica' THEN 'JES-018-VIP'
    WHEN 'Tobiwah Idris' THEN 'TOB-019-VIP'
    WHEN 'Leticia' THEN 'LET-020-VIP'
    WHEN 'Grace Odianamhti' THEN 'GRA-021-VIP'
    WHEN 'Goodness Love Omanu' THEN 'GOO-022-VIP'
    WHEN 'Benson Opure C.' THEN 'BEN-023-VIP'
    WHEN 'Imani Joy E.' THEN 'IMA-024-VIP'
    WHEN 'Ikhena Jessica' THEN 'IKH-025-VIP'
    WHEN 'Faithfuful Odum' THEN 'FAI-026-VIP'
    WHEN 'Sovereignty' THEN 'SOV-027-VIP'
    WHEN 'Godspower' THEN 'GOD-028-VIP'
    WHEN 'Along' THEN 'ALO-029-VIP'
    WHEN 'Rejoice' THEN 'REJ-030-VIP'
    WHEN 'Otun Godsfavour' THEN 'OTU-031-VIP'
    WHEN 'Sumailag Aliya' THEN 'SUM-032-VIP'
    WHEN 'Grace Ajebosle' THEN 'GRA-033-VIP'
    WHEN 'Patience Inegbenandian' THEN 'PAT-034-VIP'
    WHEN 'Rachel Eyelehitale' THEN 'RAC-035-VIP'
    WHEN 'Grace Adodo' THEN 'GRA-036-VIP'
    WHEN 'Wealth' THEN 'WEA-037-VIP'
    WHEN 'Faith' THEN 'FAI-038-VIP'
    WHEN 'Eleos Emma' THEN 'ELE-039-VIP'
    WHEN 'Hannah' THEN 'HAN-040-VIP'
    WHEN 'Rejoice Valerie' THEN 'REJ-041-VIP'
    
    -- VVIP Tickets
    WHEN 'Simon Joseph O.' THEN 'SIM-001-VVI'
    WHEN 'Joshua U. Cisco' THEN 'JOS-002-VVI'
    WHEN 'Courage Melody' THEN 'COU-003-VVI'
    WHEN 'Arnold Odive' THEN 'ARN-004-VVI'
    WHEN 'Fatima Adekunji' THEN 'FAT-005-VVI'
    WHEN 'Aisha Mu Sheriff' THEN 'AIS-006-VVI'
    WHEN 'Hesiba Yusuf' THEN 'HES-007-VVI'
    WHEN 'Pascal Ojito' THEN 'PAS-008-VVI'
    WHEN 'Kelvin' THEN 'KEL-009-VVI'
    WHEN 'Destiny Akhere' THEN 'DES-010-VVI'
    WHEN 'Leon Abunner' THEN 'LEO-011-VVI'
    WHEN 'Abduldimen Marian' THEN 'ABD-012-VVI'
    WHEN 'Monday' THEN 'MON-013-VVI'
    WHEN 'Collins Emuhan' THEN 'COL-014-VVI'
    WHEN 'Eustace' THEN 'EUS-015-VVI'
    WHEN 'Bensolight' THEN 'BEN-016-VVI'
    WHEN 'Lawrity' THEN 'LAW-017-VVI'
    WHEN 'Diva' THEN 'DIV-018-VVI'
    WHEN 'Orie D. Anamdi' THEN 'ORI-019-VVI'
    WHEN 'Salome Pans' THEN 'SAL-020-VVI'
    WHEN 'Big K' THEN 'BIG-021-VVI'
    WHEN 'Mary Okorowo' THEN 'MAR-022-VVI'
    WHEN 'Ebose' THEN 'EBO-023-VVI'
    WHEN 'Ella' THEN 'ELL-024-VVI'
    WHEN 'Juliet' THEN 'JUL-025-VVI'
    WHEN 'Faustina' THEN 'FAU-026-VVI'
    WHEN 'Promise M.' THEN 'PRO-027-VVI'
    WHEN 'P.D.C' THEN 'PDC-028-VVI'
    WHEN 'Prince Ebenezer' THEN 'PRI-029-VVI'
    WHEN 'Princess Esehe' THEN 'PRI-030-VVI'
    WHEN 'Pablo' THEN 'PAB-031-VVI'
    WHEN 'Premy' THEN 'PRE-032-VVI'
    WHEN 'James Igogo' THEN 'JAM-033-VVI'
    WHEN 'Japheth' THEN 'JAP-034-VVI'
    WHEN 'Audu Blessing' THEN 'AUD-035-VVI'
    WHEN 'Wilson Christiana Abunere' THEN 'WIL-036-VVI'
    WHEN 'Wisdom Dantie' THEN 'WIS-037-VVI'
    WHEN 'Destiny Okhale' THEN 'DES-038-VVI'
    WHEN 'Huncho Odia' THEN 'HUN-039-VVI'
    WHEN 'Rejoice Omonigho' THEN 'REJ-040-VVI'
    WHEN 'Omon Blessing' THEN 'OMO-041-VVI'
    WHEN 'Asue' THEN 'ASU-042-VVI'
    WHEN 'Goodness Omokaro' THEN 'GOO-043-VVI'
    WHEN 'Derrick' THEN 'DER-044-VVI'
    WHEN 'Benita' THEN 'BEN-045-VVI'
    WHEN 'Abel' THEN 'ABE-046-VVI'
  END;

-- Show all verification codes
SELECT name, amount_paid, verification_code,
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
  END as ticket_type
FROM paid_names 
ORDER BY amount_paid, name;
