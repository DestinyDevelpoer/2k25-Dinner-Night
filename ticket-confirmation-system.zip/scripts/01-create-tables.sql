-- Create tickets table
CREATE TABLE IF NOT EXISTS tickets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  ticket_type TEXT NOT NULL CHECK (ticket_type IN ('regular', 'vip', 'vvip')),
  ticket_price INTEGER NOT NULL,
  picture_url TEXT,
  receipt_url TEXT NOT NULL,
  verification_link TEXT UNIQUE NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'rejected')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create paid_names table for predefined names
CREATE TABLE IF NOT EXISTS paid_names (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  amount_paid INTEGER NOT NULL,
  is_used BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert sample paid names
INSERT INTO paid_names (name, amount_paid) VALUES
  ('John Doe', 2000),
  ('Jane Smith', 5000),
  ('Mike Johnson', 10000),
  ('Sarah Wilson', 2000),
  ('David Brown', 5000),
  ('Lisa Davis', 10000),
  ('Tom Anderson', 2000),
  ('Emma Taylor', 5000),
  ('Chris Martin', 10000),
  ('Amy White', 2000)
ON CONFLICT (name) DO NOTHING;

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default admin user (password: admin123)
INSERT INTO admin_users (username, password_hash) VALUES
  ('admin', '$2a$10$rOvHjHxqz0oUhulxVlSIL.WjWBksRqM8S6WvMQeQtJ5kGjLxK5O6e')
ON CONFLICT (username) DO NOTHING;
