-- Create a function to automatically generate verification codes
CREATE OR REPLACE FUNCTION generate_verification_code_for_new_name()
RETURNS TRIGGER AS $$
DECLARE
  name_prefix TEXT;
  type_suffix TEXT;
  sequence_num TEXT;
  new_code TEXT;
  existing_codes TEXT[];
  counter INTEGER := 1;
BEGIN
  -- Only generate if verification_code is NULL or empty
  IF NEW.verification_code IS NULL OR NEW.verification_code = '' THEN
    -- Get existing codes to ensure uniqueness
    SELECT ARRAY(SELECT verification_code FROM paid_names WHERE verification_code IS NOT NULL AND verification_code != '') 
    INTO existing_codes;
    
    -- Generate name prefix (first 3 letters, uppercase)
    name_prefix := UPPER(SUBSTRING(REGEXP_REPLACE(NEW.name, '[^a-zA-Z]', '', 'g'), 1, 3));
    IF LENGTH(name_prefix) < 3 THEN
      name_prefix := RPAD(name_prefix, 3, 'X');
    END IF;
    
    -- Determine ticket type suffix based on amount
    IF NEW.amount_paid = 5000 THEN
      type_suffix := 'VIP';
    ELSIF NEW.amount_paid = 10000 THEN
      type_suffix := 'VVI';
    ELSIF NEW.amount_paid > 3000 AND NEW.amount_paid < 5000 THEN
      type_suffix := 'VIP';
    ELSIF NEW.amount_paid > 10000 THEN
      type_suffix := 'VVI';
    ELSE
      type_suffix := 'REG';
    END IF;
    
    -- Generate sequence number (3 digits)
    sequence_num := LPAD((ARRAY_LENGTH(existing_codes, 1) + 1)::TEXT, 3, '0');
    
    -- Create the verification code
    new_code := name_prefix || '-' || sequence_num || '-' || type_suffix;
    
    -- Ensure uniqueness by adding counter if needed
    WHILE new_code = ANY(existing_codes) LOOP
      new_code := name_prefix || '-' || sequence_num || counter::TEXT || '-' || type_suffix;
      counter := counter + 1;
    END LOOP;
    
    -- Set the generated code
    NEW.verification_code := new_code;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically generate verification codes
DROP TRIGGER IF EXISTS auto_generate_verification_code ON paid_names;
CREATE TRIGGER auto_generate_verification_code
  BEFORE INSERT ON paid_names
  FOR EACH ROW
  EXECUTE FUNCTION generate_verification_code_for_new_name();

-- Update any existing names without verification codes
UPDATE paid_names 
SET verification_code = NULL 
WHERE verification_code IS NULL OR verification_code = '';

-- The trigger will automatically generate codes for the updated rows
-- Let's manually update them to trigger the function
DO $$
DECLARE
  name_record RECORD;
  name_prefix TEXT;
  type_suffix TEXT;
  sequence_num TEXT;
  new_code TEXT;
  existing_codes TEXT[];
  counter INTEGER;
BEGIN
  -- Get all existing codes
  SELECT ARRAY(SELECT verification_code FROM paid_names WHERE verification_code IS NOT NULL AND verification_code != '') 
  INTO existing_codes;
  
  -- Update names without codes
  FOR name_record IN 
    SELECT id, name, amount_paid 
    FROM paid_names 
    WHERE verification_code IS NULL OR verification_code = ''
  LOOP
    counter := 1;
    
    -- Generate name prefix
    name_prefix := UPPER(SUBSTRING(REGEXP_REPLACE(name_record.name, '[^a-zA-Z]', '', 'g'), 1, 3));
    IF LENGTH(name_prefix) < 3 THEN
      name_prefix := RPAD(name_prefix, 3, 'X');
    END IF;
    
    -- Determine type suffix
    IF name_record.amount_paid = 5000 THEN
      type_suffix := 'VIP';
    ELSIF name_record.amount_paid = 10000 THEN
      type_suffix := 'VVI';
    ELSIF name_record.amount_paid > 3000 AND name_record.amount_paid < 5000 THEN
      type_suffix := 'VIP';
    ELSIF name_record.amount_paid > 10000 THEN
      type_suffix := 'VVI';
    ELSE
      type_suffix := 'REG';
    END IF;
    
    -- Generate sequence
    sequence_num := LPAD((ARRAY_LENGTH(existing_codes, 1) + 1)::TEXT, 3, '0');
    
    -- Create code
    new_code := name_prefix || '-' || sequence_num || '-' || type_suffix;
    
    -- Ensure uniqueness
    WHILE new_code = ANY(existing_codes) LOOP
      new_code := name_prefix || '-' || sequence_num || counter::TEXT || '-' || type_suffix;
      counter := counter + 1;
    END LOOP;
    
    -- Update the record
    UPDATE paid_names 
    SET verification_code = new_code 
    WHERE id = name_record.id;
    
    -- Add to existing codes array
    existing_codes := existing_codes || new_code;
  END LOOP;
END $$;

-- Show updated results
SELECT name, amount_paid, verification_code,
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
    ELSE 'Regular'
  END as ticket_type
FROM paid_names 
ORDER BY amount_paid, name;
