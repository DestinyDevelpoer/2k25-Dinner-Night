-- Add verification_code column to paid_names if not exists
ALTER TABLE paid_names ADD COLUMN IF NOT EXISTS verification_code TEXT UNIQUE;

-- Update tickets table to remove receipt_url requirement and add verification_code
ALTER TABLE tickets ALTER COLUMN receipt_url DROP NOT NULL;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS verification_code TEXT;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_paid_names_verification_code ON paid_names(verification_code);
CREATE INDEX IF NOT EXISTS idx_tickets_verification_code ON tickets(verification_code);
