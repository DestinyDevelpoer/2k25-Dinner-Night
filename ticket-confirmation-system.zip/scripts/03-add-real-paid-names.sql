-- Clear existing sample data
DELETE FROM paid_names;

-- Insert all real paid names
INSERT INTO paid_names (name, amount_paid) VALUES
-- Regular Tickets (₦2,000 - ₦3,000)
('Prudence', 2000),
('Sule Glory Lukman', 2000),
('Oluwatoyin', 2000),
('Louisa', 2000),
('Ifun', 2000),
('Faith Oseriemen', 3000),
('Idris Miriam', 3000),
('Halima', 2000),
('Fauza', 2000),
('Farida', 2000),
('Best', 2000),
('Ryce', 2000),
('Favour Osehi', 2000),
('Cherish', 2000),
('Grace Onostate', 2000),
('Bernice', 2000),
('Esther', 2000),
('Olaye Victory', 2000),

-- VIP Tickets (₦5,000)
('Aitoye Orime', 5000),
('Odim Gift', 5000),
('Augustina Agbaye', 5000),
('Adsuwa Slyvia Oshio', 5000),
('Aikhomu Michael P.', 5000),
('Testimony Ejohi A.', 5000),
('Blessing Precious M.', 5000),
('Destiny Oche', 5000),
('Victoria Verekee', 5000),
('Lucia', 5000),
('Steven Francesca Ikhai Alasa', 5000),
('Sado Sweet', 5000),
('Eze Chidera', 5000),
('Udegbe Ose', 5000),
('Precious Ethis', 5000),
('Bella', 5000),
('Agape Peter', 5000),
('Jessica', 5000),
('Tobiwah Idris', 5000),
('Leticia', 5000),
('Grace Odianamhti', 5000),
('Goodness Love Omanu', 5000),
('Benson Opure C.', 5000),
('Imani Joy E.', 5000),
('Ikhena Jessica', 5000),
('Faithfuful Odum', 5000),
('Sovereignty', 5000),
('Godspower', 5000),
('Along', 5000),
('Rejoice', 5000),
('Otun Godsfavour', 5000),
('Sumailag Aliya', 5000),
('Grace Ajebosle', 5000),
('Patience Inegbenandian', 5000),
('Rachel Eyelehitale', 5000),
('Grace Adodo', 5000),
('Wealth', 5000),
('Faith', 5000),
('Eleos Emma', 5000),
('Hannah', 5000),
('Rejoice Valerie', 5000),

-- VVIP Tickets (₦10,000)
('Simon Joseph O.', 10000),
('Joshua U. Cisco', 10000),
('Courage Melody', 10000),
('Arnold Odive', 10000),
('Fatima Adekunji', 10000),
('Aisha Mu Sheriff', 10000),
('Hesiba Yusuf', 10000),
('Pascal Ojito', 10000),
('Kelvin', 10000),
('Destiny Akhere', 10000),
('Leon Abunner', 10000),
('Abduldimen Marian', 10000),
('Monday', 10000),
('Collins Emuhan', 10000),
('Eustace', 10000),
('Bensolight', 10000),
('Lawrity', 10000),
('Diva', 10000),
('Orie D. Anamdi', 10000),
('Salome Pans', 10000),
('Big K', 10000),
('Mary Okorowo', 10000),
('Ebose', 10000),
('Ella', 10000),
('Juliet', 10000),
('Faustina', 10000),
('Promise M.', 10000),
('P.D.C', 10000),
('Prince Ebenezer', 10000),
('Princess Esehe', 10000),
('Pablo', 10000),
('Premy', 10000),
('James Igogo', 10000),
('Japheth', 10000),
('Audu Blessing', 10000),
('Wilson Christiana Abunere', 10000),
('Wisdom Dantie', 10000),
('Destiny Okhale', 10000),
('Huncho Odia', 10000),
('Rejoice Omonigho', 10000),
('Omon Blessing', 10000),
('Asue', 10000),
('Goodness Omokaro', 10000),
('Derrick', 10000),
('Benita', 10000),
('Abel', 10000);

-- Show summary
SELECT 
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
  END as ticket_category,
  COUNT(*) as count,
  SUM(amount_paid) as total_amount
FROM paid_names 
GROUP BY 
  CASE 
    WHEN amount_paid <= 3000 THEN 'Regular'
    WHEN amount_paid = 5000 THEN 'VIP'
    WHEN amount_paid = 10000 THEN 'VVIP'
  END
ORDER BY total_amount;
