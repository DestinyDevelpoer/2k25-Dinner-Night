"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Send, Mail, MessageSquare, ArrowLeft, Bell, CheckCircle, Clock } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

interface NotificationTemplate {
  id: string
  name: string
  subject: string
  message: string
  type: "email" | "sms" | "whatsapp"
  created_at: string
}

interface Attendee {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: string
  verification_code: string
}

export default function NotificationsPage() {
  const [attendees, setAttendees] = useState<Attendee[]>([])
  const [selectedAttendees, setSelectedAttendees] = useState<string[]>([])
  const [messageType, setMessageType] = useState<"email" | "sms" | "whatsapp">("email")
  const [subject, setSubject] = useState("")
  const [message, setMessage] = useState("")
  const [sending, setSending] = useState(false)
  const [sentMessages, setSentMessages] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("admin_authenticated")
    if (!isAuthenticated) {
      router.push("/admin/login")
      return
    }
    fetchAttendees()
  }, [router])

  const fetchAttendees = async () => {
    try {
      const { data: tickets } = await supabase.from("tickets").select("*").order("created_at", { ascending: false })

      if (tickets) {
        setAttendees(tickets)
      }
    } catch (error) {
      console.error("Error fetching attendees:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSelectAll = () => {
    if (selectedAttendees.length === attendees.length) {
      setSelectedAttendees([])
    } else {
      setSelectedAttendees(attendees.map((a) => a.id))
    }
  }

  const handleSelectAttendee = (id: string) => {
    setSelectedAttendees((prev) => (prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]))
  }

  const sendNotifications = async () => {
    if (!subject || !message || selectedAttendees.length === 0) {
      alert("Please fill in all fields and select at least one attendee")
      return
    }

    setSending(true)
    try {
      const selectedAttendeesData = attendees.filter((a) => selectedAttendees.includes(a.id))

      // Simulate sending notifications (in real app, integrate with email/SMS service)
      const notifications = selectedAttendeesData.map((attendee) => ({
        id: Math.random().toString(36).substr(2, 9),
        attendee_name: attendee.name,
        attendee_email: attendee.email,
        attendee_phone: attendee.phone,
        type: messageType,
        subject,
        message: message.replace("{{name}}", attendee.name).replace("{{code}}", attendee.verification_code),
        status: "sent",
        sent_at: new Date().toISOString(),
      }))

      setSentMessages((prev) => [...notifications, ...prev])

      // Clear form
      setSelectedAttendees([])
      setSubject("")
      setMessage("")

      alert(`Successfully sent ${notifications.length} ${messageType} notifications!`)
    } catch (error) {
      console.error("Error sending notifications:", error)
      alert("Failed to send notifications. Please try again.")
    } finally {
      setSending(false)
    }
  }

  const messageTemplates = {
    email: {
      reminder: {
        subject: "🎉 Reminder: 2K25 Dinner Party Tomorrow!",
        message: `Hi {{name}},

This is a friendly reminder that the 2K25 Dinner Party is tomorrow!

📅 Date: June 21, 2025
🕰️ Time: 7:00 PM - 12:00 AM
📍 Venue: Mudiame University, Irrua Campus

Your verification code: {{code}}

Please bring this code for entry verification.

See you there!
Best regards,
2K25 Event Team`,
      },
      welcome: {
        subject: "✅ Welcome to 2K25 Dinner Party!",
        message: `Dear {{name}},

Welcome to the 2K25 Dinner Party! We're excited to have you join us.

Your verification code: {{code}}

Event Details:
📅 June 21, 2025
🕰️ 7:00 PM - 12:00 AM  
📍 Mudiame University

Please save this code and bring it for entry verification.

Looking forward to seeing you!
2K25 Event Team`,
      },
    },
    whatsapp: {
      reminder: {
        subject: "Event Reminder",
        message: `🎉 Hi {{name}}! 

Tomorrow is the big day - 2K25 Dinner Party!

📅 June 21, 2025
🕰️ 7PM-12AM
📍 Mudiame University

Your code: {{code}}

Don't forget to bring your verification code! 🎫`,
      },
    },
  }

  const loadTemplate = (templateType: string) => {
    const template = messageTemplates[messageType]?.[templateType]
    if (template) {
      setSubject(template.subject)
      setMessage(template.message)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-8 px-4">
      {/* Header */}
      <header className="mb-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-white">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Admin
            </Button>
          </Link>
          <div className="text-right">
            <p className="text-sm opacity-80">Notifications:</p>
            <p className="font-semibold">2K25 Dinner Party</p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-2">📢 Notification Center</h1>
          <p className="text-white/70">Send updates and reminders to attendees</p>
        </div>

        <Tabs defaultValue="compose" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="compose" className="text-white data-[state=active]:bg-white/20">
              <Send className="h-4 w-4 mr-2" />
              Compose Message
            </TabsTrigger>
            <TabsTrigger value="history" className="text-white data-[state=active]:bg-white/20">
              <Clock className="h-4 w-4 mr-2" />
              Message History ({sentMessages.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="compose">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Message Composer */}
              <div className="lg:col-span-2">
                <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white">Compose Message</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Message Type */}
                    <div className="space-y-2">
                      <Label className="text-white">Message Type</Label>
                      <Select
                        value={messageType}
                        onValueChange={(value: "email" | "sms" | "whatsapp") => setMessageType(value)}
                      >
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">
                            <div className="flex items-center gap-2">
                              <Mail className="h-4 w-4" />
                              Email
                            </div>
                          </SelectItem>
                          <SelectItem value="whatsapp">
                            <div className="flex items-center gap-2">
                              <MessageSquare className="h-4 w-4" />
                              WhatsApp
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Quick Templates */}
                    <div className="space-y-2">
                      <Label className="text-white">Quick Templates</Label>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => loadTemplate("welcome")}
                          className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        >
                          Welcome Message
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => loadTemplate("reminder")}
                          className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        >
                          Event Reminder
                        </Button>
                      </div>
                    </div>

                    {/* Subject */}
                    <div className="space-y-2">
                      <Label className="text-white">Subject</Label>
                      <Input
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        placeholder="Enter message subject"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                      />
                    </div>

                    {/* Message */}
                    <div className="space-y-2">
                      <Label className="text-white">Message</Label>
                      <Textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Enter your message... Use {{name}} for attendee name and {{code}} for verification code"
                        rows={8}
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                      />
                      <p className="text-xs text-white/60">{"Available variables: {{name}}, {{code}}"}</p>
                    </div>

                    {/* Send Button */}
                    <Button
                      onClick={sendNotifications}
                      disabled={sending || selectedAttendees.length === 0}
                      className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                    >
                      {sending ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Send to {selectedAttendees.length} attendee(s)
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Attendee Selection */}
              <div>
                <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span>Select Attendees</span>
                      <Badge variant="outline" className="bg-white/10 text-white border-white/20">
                        {selectedAttendees.length}/{attendees.length}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleSelectAll}
                        className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20"
                      >
                        {selectedAttendees.length === attendees.length ? "Deselect All" : "Select All"}
                      </Button>

                      <div className="max-h-96 overflow-y-auto space-y-2">
                        {attendees.map((attendee) => (
                          <div
                            key={attendee.id}
                            className={`p-3 rounded-lg cursor-pointer transition-colors ${
                              selectedAttendees.includes(attendee.id)
                                ? "bg-blue-500/30 border border-blue-400/50"
                                : "bg-white/5 hover:bg-white/10"
                            }`}
                            onClick={() => handleSelectAttendee(attendee.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-white font-medium text-sm">{attendee.name}</p>
                                <p className="text-white/60 text-xs">
                                  {attendee.email || attendee.phone || "No contact"}
                                </p>
                              </div>
                              <Badge
                                className={`text-xs ${
                                  attendee.ticket_type === "regular"
                                    ? "bg-blue-100 text-blue-800"
                                    : attendee.ticket_type === "vip"
                                      ? "bg-purple-100 text-purple-800"
                                      : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {attendee.ticket_type.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Message History</CardTitle>
              </CardHeader>
              <CardContent>
                {sentMessages.length === 0 ? (
                  <div className="text-center py-8">
                    <Bell className="h-12 w-12 text-white/40 mx-auto mb-4" />
                    <p className="text-white/60">No messages sent yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {sentMessages.map((msg) => (
                      <div key={msg.id} className="p-4 bg-white/5 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="text-white font-medium">{msg.subject}</h3>
                            <p className="text-white/60 text-sm">To: {msg.attendee_name}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="bg-green-500/20 text-green-300 border-green-400/30">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              {msg.status}
                            </Badge>
                            <Badge variant="outline" className="bg-blue-500/20 text-blue-300 border-blue-400/30">
                              {msg.type}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-white/80 text-sm mb-2">{msg.message.substring(0, 100)}...</p>
                        <p className="text-white/50 text-xs">Sent: {new Date(msg.sent_at).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
