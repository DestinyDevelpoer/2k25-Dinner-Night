"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"
import { TrendingUp, Users, DollarSign, ArrowLeft, Download, RefreshCw, Clock, Target, Award } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

interface AnalyticsData {
  totalRevenue: number
  totalTickets: number
  conversionRate: number
  averageTicketValue: number
  ticketsByType: { name: string; value: number; color: string }[]
  revenueByType: { name: string; value: number }[]
  dailyRegistrations: { date: string; count: number }[]
  topSpenders: { name: string; amount: number }[]
  usageStats: { used: number; available: number }
}

const COLORS = ["#3B82F6", "#8B5CF6", "#F59E0B", "#10B981"]

export default function AnalyticsPage() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("7d")
  const router = useRouter()

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("admin_authenticated")
    if (!isAuthenticated) {
      router.push("/admin/login")
      return
    }
    fetchAnalytics()
  }, [router, timeRange])

  const fetchAnalytics = async () => {
    try {
      // Fetch tickets and paid names data
      const { data: tickets } = await supabase.from("tickets").select("*")
      const { data: paidNames } = await supabase.from("paid_names").select("*")

      if (!tickets || !paidNames) return

      // Calculate analytics
      const totalRevenue = tickets.reduce((sum, t) => sum + t.ticket_price, 0)
      const totalTickets = tickets.length
      const totalPaidNames = paidNames.length
      const conversionRate = totalPaidNames > 0 ? (totalTickets / totalPaidNames) * 100 : 0
      const averageTicketValue = totalTickets > 0 ? totalRevenue / totalTickets : 0

      // Tickets by type
      const ticketsByType = [
        { name: "Regular", value: tickets.filter((t) => t.ticket_type === "regular").length, color: COLORS[0] },
        { name: "VIP", value: tickets.filter((t) => t.ticket_type === "vip").length, color: COLORS[1] },
        { name: "VVIP", value: tickets.filter((t) => t.ticket_type === "vvip").length, color: COLORS[2] },
      ]

      // Revenue by type
      const revenueByType = [
        {
          name: "Regular",
          value: tickets.filter((t) => t.ticket_type === "regular").reduce((sum, t) => sum + t.ticket_price, 0),
        },
        {
          name: "VIP",
          value: tickets.filter((t) => t.ticket_type === "vip").reduce((sum, t) => sum + t.ticket_price, 0),
        },
        {
          name: "VVIP",
          value: tickets.filter((t) => t.ticket_type === "vvip").reduce((sum, t) => sum + t.ticket_price, 0),
        },
      ]

      // Daily registrations (last 7 days)
      const dailyRegistrations = []
      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        const dateStr = date.toISOString().split("T")[0]
        const count = tickets.filter((t) => t.created_at.startsWith(dateStr)).length
        dailyRegistrations.push({ date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }), count })
      }

      // Top spenders
      const topSpenders = paidNames
        .sort((a, b) => b.amount_paid - a.amount_paid)
        .slice(0, 5)
        .map((p) => ({ name: p.name, amount: p.amount_paid }))

      // Usage stats
      const usageStats = {
        used: paidNames.filter((p) => p.is_used).length,
        available: paidNames.filter((p) => !p.is_used).length,
      }

      setAnalytics({
        totalRevenue,
        totalTickets,
        conversionRate,
        averageTicketValue,
        ticketsByType,
        revenueByType,
        dailyRegistrations,
        topSpenders,
        usageStats,
      })
    } catch (error) {
      console.error("Error fetching analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  const exportAnalytics = () => {
    if (!analytics) return

    const data = {
      summary: {
        totalRevenue: analytics.totalRevenue,
        totalTickets: analytics.totalTickets,
        conversionRate: analytics.conversionRate,
        averageTicketValue: analytics.averageTicketValue,
      },
      ticketsByType: analytics.ticketsByType,
      revenueByType: analytics.revenueByType,
      dailyRegistrations: analytics.dailyRegistrations,
      topSpenders: analytics.topSpenders,
      usageStats: analytics.usageStats,
      generatedAt: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `analytics-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    )
  }

  if (!analytics) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-center">
          <p className="text-xl mb-4">Failed to load analytics</p>
          <Button onClick={fetchAnalytics}>Try Again</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-8 px-4">
      {/* Header */}
      <header className="mb-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-white">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Admin
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm opacity-80">Event Analytics:</p>
              <p className="font-semibold">2K25 Dinner Party</p>
            </div>
            <Button
              onClick={exportAnalytics}
              variant="outline"
              size="sm"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button
              onClick={fetchAnalytics}
              variant="outline"
              size="sm"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-2">📊 Event Analytics Dashboard</h1>
          <p className="text-white/70">Comprehensive insights and performance metrics</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/70">Total Revenue</p>
                  <p className="text-3xl font-bold text-white">₦{analytics.totalRevenue.toLocaleString()}</p>
                  <p className="text-xs text-green-400 mt-1">
                    <TrendingUp className="h-3 w-3 inline mr-1" />
                    Avg: ₦{Math.round(analytics.averageTicketValue).toLocaleString()}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/70">Total Tickets</p>
                  <p className="text-3xl font-bold text-white">{analytics.totalTickets}</p>
                  <p className="text-xs text-blue-400 mt-1">
                    <Users className="h-3 w-3 inline mr-1" />
                    Confirmed attendees
                  </p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/70">Conversion Rate</p>
                  <p className="text-3xl font-bold text-white">{analytics.conversionRate.toFixed(1)}%</p>
                  <p className="text-xs text-purple-400 mt-1">
                    <Target className="h-3 w-3 inline mr-1" />
                    Paid to confirmed
                  </p>
                </div>
                <Target className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/70">Available Spots</p>
                  <p className="text-3xl font-bold text-white">{analytics.usageStats.available}</p>
                  <p className="text-xs text-yellow-400 mt-1">
                    <Clock className="h-3 w-3 inline mr-1" />
                    Ready to confirm
                  </p>
                </div>
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Ticket Distribution */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Ticket Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={analytics.ticketsByType}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {analytics.ticketsByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Revenue by Type */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Revenue by Ticket Type</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.revenueByType}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151" }}
                    labelStyle={{ color: "#F3F4F6" }}
                  />
                  <Bar dataKey="value" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Daily Registrations */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Daily Registrations (Last 7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={analytics.dailyRegistrations}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="date" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151" }}
                    labelStyle={{ color: "#F3F4F6" }}
                  />
                  <Line type="monotone" dataKey="count" stroke="#10B981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Spenders */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Award className="h-5 w-5 text-yellow-400" />
                Top Spenders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.topSpenders.map((spender, index) => (
                  <div key={spender.name} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                          index === 0
                            ? "bg-yellow-500 text-black"
                            : index === 1
                              ? "bg-gray-400 text-black"
                              : index === 2
                                ? "bg-orange-600 text-white"
                                : "bg-blue-500 text-white"
                        }`}
                      >
                        {index + 1}
                      </div>
                      <span className="text-white font-medium">{spender.name}</span>
                    </div>
                    <Badge variant="outline" className="bg-green-500/20 text-green-300 border-green-400/30">
                      ₦{spender.amount.toLocaleString()}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Usage Statistics */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Usage Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">{analytics.usageStats.used}</div>
                <p className="text-white/70">Tickets Used</p>
                <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                  <div
                    className="bg-green-400 h-2 rounded-full"
                    style={{
                      width: `${(analytics.usageStats.used / (analytics.usageStats.used + analytics.usageStats.available)) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="text-center">
                <div className="text-4xl font-bold text-blue-400 mb-2">{analytics.usageStats.available}</div>
                <p className="text-white/70">Available Spots</p>
                <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                  <div
                    className="bg-blue-400 h-2 rounded-full"
                    style={{
                      width: `${(analytics.usageStats.available / (analytics.usageStats.used + analytics.usageStats.available)) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="text-center">
                <div className="text-4xl font-bold text-purple-400 mb-2">
                  {analytics.usageStats.used + analytics.usageStats.available}
                </div>
                <p className="text-white/70">Total Capacity</p>
                <div className="w-full bg-purple-400 rounded-full h-2 mt-2"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
