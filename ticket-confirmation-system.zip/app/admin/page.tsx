"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users,
  Ticket,
  DollarSign,
  Eye,
  Trash2,
  Plus,
  Edit,
  RefreshCw,
  Shield,
  ArrowLeft,
  Download,
  Upload,
  LogOut,
  Database,
  BarChart3,
  Bell,
  TrendingUp,
} from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

interface TicketData {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: "regular" | "vip" | "vvip"
  ticket_price: number
  picture_url: string | null
  verification_code: string
  verification_link: string
  status: string
  created_at: string
}

interface PaidName {
  id: string
  name: string
  amount_paid: number
  is_used: boolean
  verification_code: string
  created_at: string
}

interface Stats {
  totalTickets: number
  totalRevenue: number
  regularTickets: number
  vipTickets: number
  vvipTickets: number
  availableNames: number
  usedNames: number
}

// Function to generate a verification code
const generateVerificationCode = (name: string, amount: number, seed: number): string => {
  const namePrefix = name
    .replace(/[^a-zA-Z]/g, "")
    .substring(0, 3)
    .toUpperCase()
    .padEnd(3, "X")

  const timestamp = Date.now().toString().slice(-3)
  const sequence = String(seed + 1).padStart(3, "0")

  // Determine ticket type suffix (updated to use VVIP)
  let typeSuffix = "REG"
  if (amount === 5000) typeSuffix = "VIP"
  else if (amount === 10000) typeSuffix = "VVIP"
  else if (amount > 3000 && amount < 5000) typeSuffix = "VIP"
  else if (amount > 10000) typeSuffix = "VVIP"

  return `${namePrefix}-${sequence}-${typeSuffix}`
}

// Function to ensure the generated code is unique
const ensureUniqueCode = (code: string, existingCodes: string[]): string => {
  let newCode = code
  let counter = 1
  while (existingCodes.includes(newCode)) {
    const parts = code.split("-")
    if (parts.length === 3) {
      newCode = `${parts[0]}-${parts[1]}${counter}-${parts[2]}`
    } else {
      newCode = `${code}-${counter}`
    }
    counter++
  }
  return newCode
}

export default function AdminPage() {
  const [tickets, setTickets] = useState<TicketData[]>([])
  const [paidNames, setPaidNames] = useState<PaidName[]>([])
  const [stats, setStats] = useState<Stats>({
    totalTickets: 0,
    totalRevenue: 0,
    regularTickets: 0,
    vipTickets: 0,
    vvipTickets: 0,
    availableNames: 0,
    usedNames: 0,
  })
  const [loading, setLoading] = useState(true)
  const [newName, setNewName] = useState("")
  const [newAmount, setNewAmount] = useState("")
  const [editingName, setEditingName] = useState<PaidName | null>(null)
  const [editingTicket, setEditingTicket] = useState<TicketData | null>(null)
  const [editName, setEditName] = useState("")
  const [editAmount, setEditAmount] = useState("")
  const [editTicketStatus, setEditTicketStatus] = useState("")
  const [bulkNames, setBulkNames] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const router = useRouter()

  useEffect(() => {
    // Check admin authentication
    const isAuthenticated = localStorage.getItem("admin_authenticated")
    if (!isAuthenticated) {
      router.push("/admin/login")
      return
    }
    fetchData()
  }, [router])

  const fetchData = async () => {
    try {
      // Fetch tickets
      const { data: ticketsData, error: ticketsError } = await supabase
        .from("tickets")
        .select("*")
        .order("created_at", { ascending: false })

      if (ticketsError) throw ticketsError

      // Fetch paid names
      const { data: namesData, error: namesError } = await supabase
        .from("paid_names")
        .select("*")
        .order("created_at", { ascending: false })

      if (namesError) throw namesError

      setTickets(ticketsData || [])
      setPaidNames(namesData || [])

      // Calculate comprehensive stats
      if (ticketsData && namesData) {
        const totalRevenue = ticketsData.reduce((sum, ticket) => sum + ticket.ticket_price, 0)
        const regularTickets = ticketsData.filter((t) => t.ticket_type === "regular").length
        const vipTickets = ticketsData.filter((t) => t.ticket_type === "vip").length
        const vvipTickets = ticketsData.filter((t) => t.ticket_type === "vvip").length
        const availableNames = namesData.filter((n) => !n.is_used).length
        const usedNames = namesData.filter((n) => n.is_used).length

        setStats({
          totalTickets: ticketsData.length,
          totalRevenue,
          regularTickets,
          vipTickets,
          vvipTickets,
          availableNames,
          usedNames,
        })
      }
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("admin_authenticated")
    localStorage.removeItem("admin_user")
    router.push("/admin/login")
  }

  const addPaidName = async () => {
    if (!newName || !newAmount) return

    try {
      // Get existing codes to ensure uniqueness
      const { data: existingNames, error: fetchError } = await supabase.from("paid_names").select("verification_code")

      if (fetchError) throw fetchError

      const existingCodes = existingNames?.map((n) => n.verification_code).filter(Boolean) || []

      // Generate unique verification code
      const generatedCode = generateVerificationCode(newName.trim(), Number.parseInt(newAmount), existingCodes.length)
      const uniqueCode = ensureUniqueCode(generatedCode, existingCodes)

      const { error } = await supabase.from("paid_names").insert({
        name: newName.trim(),
        amount_paid: Number.parseInt(newAmount),
        verification_code: uniqueCode,
      })

      if (error) throw error

      setNewName("")
      setNewAmount("")
      fetchData()
    } catch (error) {
      console.error("Error adding paid name:", error)
      alert("Error adding name. Please try again.")
    }
  }

  const updatePaidName = async () => {
    if (!editingName || !editName || !editAmount) return

    try {
      const { error } = await supabase
        .from("paid_names")
        .update({
          name: editName.trim(),
          amount_paid: Number.parseInt(editAmount),
        })
        .eq("id", editingName.id)

      if (error) throw error

      setEditingName(null)
      setEditName("")
      setEditAmount("")
      fetchData()
    } catch (error) {
      console.error("Error updating paid name:", error)
      alert("Error updating name. Please try again.")
    }
  }

  const updateTicketStatus = async () => {
    if (!editingTicket || !editTicketStatus) return

    try {
      const { error } = await supabase.from("tickets").update({ status: editTicketStatus }).eq("id", editingTicket.id)

      if (error) throw error

      setEditingTicket(null)
      setEditTicketStatus("")
      fetchData()
    } catch (error) {
      console.error("Error updating ticket:", error)
      alert("Error updating ticket. Please try again.")
    }
  }

  const deletePaidName = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) return

    try {
      const { error } = await supabase.from("paid_names").delete().eq("id", id)

      if (error) throw error
      fetchData()
    } catch (error) {
      console.error("Error deleting paid name:", error)
      alert("Error deleting name. Please try again.")
    }
  }

  const deleteTicket = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete ticket for "${name}"? This action cannot be undone.`)) return

    try {
      const { error } = await supabase.from("tickets").delete().eq("id", id)

      if (error) throw error
      fetchData()
    } catch (error) {
      console.error("Error deleting ticket:", error)
      alert("Error deleting ticket. Please try again.")
    }
  }

  const resetUsedStatus = async (id: string) => {
    try {
      const { error } = await supabase.from("paid_names").update({ is_used: false }).eq("id", id)

      if (error) throw error
      fetchData()
    } catch (error) {
      console.error("Error resetting status:", error)
      alert("Error resetting status. Please try again.")
    }
  }

  const addBulkNames = async () => {
    if (!bulkNames.trim()) return

    try {
      const lines = bulkNames.trim().split("\n")

      // Get existing codes first
      const { data: existingNames, error: fetchError } = await supabase.from("paid_names").select("verification_code")

      if (fetchError) throw fetchError

      const existingCodes = existingNames?.map((n) => n.verification_code).filter(Boolean) || []
      const namesToAdd = []

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i]
        const parts = line.split(":")
        if (parts.length === 2) {
          const name = parts[0].trim()
          const amount = Number.parseInt(parts[1].trim())
          if (name && !Number.isNaN(amount)) {
            // Generate unique code for each name
            const generatedCode = generateVerificationCode(name, amount, existingCodes.length + namesToAdd.length)
            const uniqueCode = ensureUniqueCode(generatedCode, [
              ...existingCodes,
              ...namesToAdd.map((n) => n.verification_code),
            ])

            namesToAdd.push({
              name,
              amount_paid: amount,
              verification_code: uniqueCode,
            })
          }
        }
      }

      if (namesToAdd.length === 0) {
        alert("No valid entries found. Use format: Name: Amount")
        return
      }

      const { error } = await supabase.from("paid_names").insert(namesToAdd)

      if (error) throw error

      setBulkNames("")
      fetchData()
      alert(`Successfully added ${namesToAdd.length} names with verification codes!`)
    } catch (error) {
      console.error("Error adding bulk names:", error)
      alert("Error adding names. Please check the format and try again.")
    }
  }

  const exportData = (type: "tickets" | "names") => {
    const data = type === "tickets" ? tickets : paidNames
    const csv =
      type === "tickets"
        ? "Name,Email,Phone,Ticket Type,Amount,Status,Verification Code,Date\n" +
          tickets
            .map(
              (t) =>
                `"${t.name}","${t.email || ""}","${t.phone || ""}","${t.ticket_type}","${t.ticket_price}","${t.status}","${t.verification_code}","${new Date(t.created_at).toLocaleDateString()}"`,
            )
            .join("\n")
        : "Name,Amount Paid,Status,Verification Code,Date Added\n" +
          paidNames
            .map(
              (n) =>
                `"${n.name}","${n.amount_paid}","${n.is_used ? "Used" : "Available"}","${n.verification_code || ""}","${new Date(n.created_at).toLocaleDateString()}"`,
            )
            .join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${type}-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const startEdit = (name: PaidName) => {
    setEditingName(name)
    setEditName(name.name)
    setEditAmount(name.amount_paid.toString())
  }

  const startEditTicket = (ticket: TicketData) => {
    setEditingTicket(ticket)
    setEditTicketStatus(ticket.status)
  }

  const getTicketTypeColor = (type: string) => {
    switch (type) {
      case "regular":
        return "bg-blue-100 text-blue-800"
      case "vip":
        return "bg-purple-100 text-purple-800"
      case "vvip":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch =
      ticket.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.verification_code.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === "all" || ticket.status === filterStatus
    return matchesSearch && matchesFilter
  })

  const filteredNames = paidNames.filter(
    (name) =>
      name.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      name.verification_code?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-8 px-4">
      {/* Header */}
      <header className="mb-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-white">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm opacity-80">Event:</p>
              <p className="font-semibold">2K25 Dinner Party</p>
              <p className="text-xs opacity-70">June 21, 2025</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="bg-red-500/20 border-red-400/30 text-red-200 hover:bg-red-500/30"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-2">🔐 Full Admin Dashboard</h1>
          <p className="text-white/70">Complete management system for 2K25 Dinner Party</p>

          {/* Quick Actions */}
          <div className="mt-6 flex flex-wrap justify-center gap-4">
            <Link href="/admin/verify">
              <Button className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white font-bold">
                <Shield className="h-4 w-4 mr-2" />
                Entry Verification
              </Button>
            </Link>
            <Link href="/admin/analytics">
              <Button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-bold">
                <TrendingUp className="h-4 w-4 mr-2" />
                Analytics Dashboard
              </Button>
            </Link>
            <Link href="/admin/notifications">
              <Button className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold">
                <Bell className="h-4 w-4 mr-2" />
                Send Notifications
              </Button>
            </Link>
            <Button
              onClick={() => exportData("tickets")}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Tickets
            </Button>
            <Button
              onClick={() => exportData("names")}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Names
            </Button>
          </div>
        </div>

        {/* Enhanced Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Users className="h-6 w-6 text-blue-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">Total Tickets</p>
                  <p className="text-xl font-bold text-white">{stats.totalTickets}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <DollarSign className="h-6 w-6 text-green-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">Revenue</p>
                  <p className="text-xl font-bold text-white">₦{stats.totalRevenue.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Ticket className="h-6 w-6 text-blue-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">Regular</p>
                  <p className="text-xl font-bold text-white">{stats.regularTickets}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Ticket className="h-6 w-6 text-purple-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">VIP</p>
                  <p className="text-xl font-bold text-white">{stats.vipTickets}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Ticket className="h-6 w-6 text-yellow-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">VVIP</p>
                  <p className="text-xl font-bold text-white">{stats.vvipTickets}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Database className="h-6 w-6 text-green-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">Available</p>
                  <p className="text-xl font-bold text-white">{stats.availableNames}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center">
                <BarChart3 className="h-6 w-6 text-orange-400" />
                <div className="ml-3">
                  <p className="text-xs font-medium text-white/70">Used</p>
                  <p className="text-xl font-bold text-white">{stats.usedNames}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="mb-6 flex flex-col md:flex-row gap-4">
          <Input
            placeholder="Search by name, email, or verification code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
          />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="bg-white/10 border-white/20 text-white md:w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="names" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="names" className="text-white data-[state=active]:bg-white/20">
              Paid Names ({paidNames.length})
            </TabsTrigger>
            <TabsTrigger value="tickets" className="text-white data-[state=active]:bg-white/20">
              Confirmed Tickets ({tickets.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="names">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-white">
                  Paid Names Management
                  <div className="flex gap-2">
                    <Button
                      onClick={() => exportData("names")}
                      variant="outline"
                      size="sm"
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button
                      onClick={fetchData}
                      variant="outline"
                      size="sm"
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Add Single Name */}
                <div className="flex gap-4 mb-6">
                  <Input
                    placeholder="Name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                  <Input
                    placeholder="Amount Paid"
                    type="number"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                  <Button
                    onClick={addPaidName}
                    className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Name
                  </Button>
                </div>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="mb-6 bg-white/10 border-white/20 text-white hover:bg-white/20">
                      <Upload className="h-4 w-4 mr-2" />
                      Bulk Add Names
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl bg-gray-900 border-gray-700">
                    <DialogHeader>
                      <DialogTitle className="text-white">Bulk Add Paid Names</DialogTitle>
                      <DialogDescription className="text-gray-300">
                        Enter names and payment amounts to add multiple attendees at once. Use the format: Name: Amount
                        (one per line).
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="bulk-names" className="text-white">
                          Enter names and amounts (one per line, format: Name: Amount)
                        </Label>
                        <textarea
                          id="bulk-names"
                          className="w-full h-64 p-3 border rounded-md bg-gray-800 border-gray-600 text-white"
                          placeholder={`John Doe: 2000
Jane Smith: 5000
Mike Johnson: 10000
Sarah Wilson: 2000`}
                          value={bulkNames}
                          onChange={(e) => setBulkNames(e.target.value)}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={addBulkNames} className="flex-1 bg-gradient-to-r from-green-500 to-blue-600">
                          Add All Names
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setBulkNames("")}
                          className="bg-white/10 border-white/20 text-white"
                        >
                          Clear
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <div className="bg-white/5 rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/20">
                        <TableHead className="text-white">Name</TableHead>
                        <TableHead className="text-white">Amount Paid</TableHead>
                        <TableHead className="text-white">Status</TableHead>
                        <TableHead className="text-white">Verification Code</TableHead>
                        <TableHead className="text-white">Date Added</TableHead>
                        <TableHead className="text-white">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredNames.map((name) => (
                        <TableRow key={name.id} className="border-white/20">
                          <TableCell className="font-medium text-white">{name.name}</TableCell>
                          <TableCell className="text-white">₦{name.amount_paid.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant={name.is_used ? "secondary" : "default"}>
                              {name.is_used ? "Used" : "Available"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white font-mono text-sm">
                            {name.verification_code || "Not assigned"}
                          </TableCell>
                          <TableCell className="text-white">{new Date(name.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startEdit(name)}
                                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              {name.is_used && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => resetUsedStatus(name.id)}
                                  className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                                >
                                  <RefreshCw className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deletePaidName(name.id, name.name)}
                                className="bg-red-500/20 border-red-400/30 text-red-200 hover:bg-red-500/30"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tickets">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-white">
                  All Confirmed Tickets
                  <div className="flex gap-2">
                    <Button
                      onClick={() => exportData("tickets")}
                      variant="outline"
                      size="sm"
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button
                      onClick={fetchData}
                      variant="outline"
                      size="sm"
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-white/5 rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/20">
                        <TableHead className="text-white">Name</TableHead>
                        <TableHead className="text-white">Contact</TableHead>
                        <TableHead className="text-white">Ticket Type</TableHead>
                        <TableHead className="text-white">Amount</TableHead>
                        <TableHead className="text-white">Status</TableHead>
                        <TableHead className="text-white">Verification Code</TableHead>
                        <TableHead className="text-white">Date</TableHead>
                        <TableHead className="text-white">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTickets.map((ticket) => (
                        <TableRow key={ticket.id} className="border-white/20">
                          <TableCell className="font-medium text-white">{ticket.name}</TableCell>
                          <TableCell className="text-white">
                            <div className="text-sm">
                              {ticket.email && <div>{ticket.email}</div>}
                              {ticket.phone && <div>{ticket.phone}</div>}
                            </div>
                          </TableCell>
                          <TableCell className={getTicketTypeColor(ticket.ticket_type)}>
                            <Badge className={getTicketTypeColor(ticket.ticket_type)}>
                              {ticket.ticket_type.toUpperCase()}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white">₦{ticket.ticket_price.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant={ticket.status === "confirmed" ? "default" : "secondary"}>
                              {ticket.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white font-mono text-sm">{ticket.verification_code}</TableCell>
                          <TableCell className="text-white">
                            {new Date(ticket.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => window.open(ticket.verification_link, "_blank")}
                                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startEditTicket(ticket)}
                                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteTicket(ticket.id, ticket.name)}
                                className="bg-red-500/20 border-red-400/30 text-red-200 hover:bg-red-500/30"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Edit Name Dialog */}
        {editingName && (
          <Dialog open={!!editingName} onOpenChange={() => setEditingName(null)}>
            <DialogContent className="bg-gray-900 border-gray-700">
              <DialogHeader>
                <DialogTitle className="text-white">Edit Paid Name</DialogTitle>
                <DialogDescription className="text-gray-300">
                  Update the name and payment amount for this attendee.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name" className="text-white">
                    Name
                  </Label>
                  <Input
                    id="edit-name"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-amount" className="text-white">
                    Amount Paid
                  </Label>
                  <Input
                    id="edit-amount"
                    type="number"
                    value={editAmount}
                    onChange={(e) => setEditAmount(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={updatePaidName} className="flex-1 bg-gradient-to-r from-green-500 to-blue-600">
                    Update
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setEditingName(null)}
                    className="bg-white/10 border-white/20 text-white"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Edit Ticket Dialog */}
        {editingTicket && (
          <Dialog open={!!editingTicket} onOpenChange={() => setEditingTicket(null)}>
            <DialogContent className="bg-gray-900 border-gray-700">
              <DialogHeader>
                <DialogTitle className="text-white">Edit Ticket Status</DialogTitle>
                <DialogDescription className="text-gray-300">Update the status of this ticket.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-status" className="text-white">
                    Ticket Status
                  </Label>
                  <Select value={editTicketStatus} onValueChange={setEditTicketStatus}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="confirmed">Confirmed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2">
                  <Button onClick={updateTicketStatus} className="flex-1 bg-gradient-to-r from-green-500 to-blue-600">
                    Update Status
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setEditingTicket(null)}
                    className="bg-white/10 border-white/20 text-white"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  )
}
