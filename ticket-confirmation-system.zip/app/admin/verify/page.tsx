"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { CheckCircle, AlertCircle, User, Mail, Phone, Ticket, Calendar, Search, ArrowLeft, Shield } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

interface TicketData {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: "regular" | "vip" | "vvip"
  ticket_price: number
  picture_url: string | null
  verification_code: string
  status: string
  created_at: string
}

export default function AdminVerifyPage() {
  const [verificationCode, setVerificationCode] = useState("")
  const [ticketData, setTicketData] = useState<TicketData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [verified, setVerified] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Check admin authentication
    const authStatus = localStorage.getItem("admin_authenticated")
    if (!authStatus) {
      router.push("/admin/login")
      return
    }
    setIsAuthenticated(true)
  }, [router])

  const searchTicket = async () => {
    if (!verificationCode.trim()) {
      setError("Please enter a verification code")
      return
    }

    setLoading(true)
    setError("")
    setTicketData(null)
    setVerified(false)

    try {
      // Search in tickets table first
      const { data: ticketResult, error: ticketError } = await supabase
        .from("tickets")
        .select("*")
        .eq("verification_code", verificationCode.trim().toUpperCase())
        .single()

      if (ticketResult) {
        setTicketData(ticketResult)
      } else {
        // If not found in tickets, check if the code exists in paid_names
        const { data: nameResult, error: nameError } = await supabase
          .from("paid_names")
          .select("*")
          .eq("verification_code", verificationCode.trim().toUpperCase())
          .single()

        if (nameResult) {
          // Create a mock ticket data from paid_names for display
          const mockTicketData: TicketData = {
            id: nameResult.id,
            name: nameResult.name,
            email: null,
            phone: null,
            ticket_type: nameResult.amount_paid <= 3000 ? "regular" : nameResult.amount_paid === 5000 ? "vip" : "vvip",
            ticket_price: nameResult.amount_paid,
            picture_url: null,
            verification_code: nameResult.verification_code,
            status: nameResult.is_used ? "used" : "valid",
            created_at: nameResult.created_at,
          }
          setTicketData(mockTicketData)
        } else {
          setError("Verification code not found. Please check the code and try again.")
        }
      }
    } catch (err) {
      console.error("Search error:", err)
      setError("Failed to verify ticket. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const grantEntry = async () => {
    if (!ticketData) return

    try {
      // Mark as verified/used in the database
      await supabase.from("paid_names").update({ is_used: true }).eq("verification_code", ticketData.verification_code)

      // If it's a confirmed ticket, update status
      if (ticketData.email || ticketData.phone) {
        await supabase
          .from("tickets")
          .update({ status: "entered" })
          .eq("verification_code", ticketData.verification_code)
      }

      setVerified(true)
    } catch (error) {
      console.error("Error granting entry:", error)
      setError("Failed to grant entry. Please try again.")
    }
  }

  const getTicketTypeColor = (type: string) => {
    switch (type) {
      case "regular":
        return "bg-blue-100 text-blue-800"
      case "vip":
        return "bg-purple-100 text-purple-800"
      case "vvip":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const resetVerification = () => {
    setVerificationCode("")
    setTicketData(null)
    setError("")
    setVerified(false)
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-8 px-4">
      {/* Header */}
      <header className="mb-8">
        <div className="max-w-4xl mx-auto flex justify-between items-center text-white">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Admin
            </Button>
          </Link>
          <div className="text-right">
            <p className="text-sm opacity-80">Event:</p>
            <p className="font-semibold">2K25 Dinner Party</p>
            <p className="text-xs opacity-70">June 21, 2025 | 7PM-12AM</p>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto">
        <Card className="bg-white/10 backdrop-blur-lg border-white/20 mb-8">
          <CardHeader className="text-center bg-gradient-to-r from-green-500/20 to-blue-500/20">
            <Shield className="h-16 w-16 text-green-400 mx-auto mb-4" />
            <CardTitle className="text-3xl font-bold text-white">🔍 Entry Verification System</CardTitle>
            <p className="text-white/80">Verify attendee codes for event entry</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="code" className="text-white text-lg">
                  Enter Attendee's Verification Code
                </Label>
                <div className="flex gap-4">
                  <Input
                    id="code"
                    type="text"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.toUpperCase())}
                    placeholder="e.g., PRU-001-REG"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 text-lg font-mono"
                    onKeyPress={(e) => e.key === "Enter" && searchTicket()}
                  />
                  <Button
                    onClick={searchTicket}
                    disabled={loading}
                    className="bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white font-semibold px-8"
                  >
                    {loading ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : (
                      <>
                        <Search className="h-4 w-4 mr-2" />
                        Verify
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {error && (
                <div className="p-4 bg-red-500/20 border border-red-400/30 rounded-lg flex items-center gap-3">
                  <AlertCircle className="h-5 w-5 text-red-400" />
                  <p className="text-red-200">{error}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {ticketData && (
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className={`text-center ${verified ? "bg-green-500/30" : "bg-blue-500/20"}`}>
              <div className="flex items-center justify-center mb-4">
                <CheckCircle className={`h-20 w-20 ${verified ? "text-green-400" : "text-blue-400"}`} />
              </div>
              <CardTitle className={`text-3xl font-bold ${verified ? "text-green-200" : "text-blue-200"}`}>
                {verified ? "✅ ENTRY GRANTED" : "🎫 ATTENDEE VERIFIED"}
              </CardTitle>
              <p className={verified ? "text-green-100 text-lg" : "text-blue-100 text-lg"}>
                {verified ? "Welcome to 2K25 Dinner Party!" : "Attendee details confirmed"}
              </p>
            </CardHeader>
            <CardContent className="p-8">
              <div className="space-y-8">
                {/* Profile Picture */}
                <div className="text-center">
                  {ticketData.picture_url ? (
                    <img
                      src={ticketData.picture_url || "/placeholder.svg"}
                      alt="Attendee Photo"
                      className="w-40 h-40 rounded-full mx-auto object-cover border-4 border-white/30 shadow-lg"
                    />
                  ) : (
                    <div className="w-40 h-40 rounded-full mx-auto bg-white/20 border-4 border-white/30 flex items-center justify-center">
                      <User className="h-20 w-20 text-white/60" />
                    </div>
                  )}
                </div>

                {/* Verification Code Display */}
                <div className="text-center bg-black/30 p-6 rounded-lg">
                  <p className="text-sm text-white/70 mb-2">Verification Code</p>
                  <div className="text-4xl font-bold font-mono text-yellow-300 bg-black/50 px-6 py-4 rounded border">
                    {ticketData.verification_code}
                  </div>
                </div>

                {/* Attendee Information */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-white/10 p-6 rounded-lg">
                      <div className="flex items-center gap-4 mb-4">
                        <User className="h-8 w-8 text-white/70" />
                        <div>
                          <p className="text-sm text-white/70">Full Name</p>
                          <p className="text-2xl font-bold text-white">{ticketData.name}</p>
                        </div>
                      </div>
                    </div>

                    {ticketData.email && (
                      <div className="bg-white/10 p-6 rounded-lg">
                        <div className="flex items-center gap-4">
                          <Mail className="h-6 w-6 text-white/70" />
                          <div>
                            <p className="text-sm text-white/70">Email</p>
                            <p className="font-semibold text-white">{ticketData.email}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {ticketData.phone && (
                      <div className="bg-white/10 p-6 rounded-lg">
                        <div className="flex items-center gap-4">
                          <Phone className="h-6 w-6 text-white/70" />
                          <div>
                            <p className="text-sm text-white/70">Phone</p>
                            <p className="font-semibold text-white">{ticketData.phone}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-6">
                    <div className="bg-white/10 p-6 rounded-lg">
                      <div className="flex items-center gap-4 mb-4">
                        <Ticket className="h-8 w-8 text-white/70" />
                        <div>
                          <p className="text-sm text-white/70">Ticket Type</p>
                          <Badge className={`${getTicketTypeColor(ticketData.ticket_type)} text-xl px-6 py-3`}>
                            {ticketData.ticket_type.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="h-8 w-8 text-white/70 flex items-center justify-center font-bold text-xl">
                          ₦
                        </div>
                        <div>
                          <p className="text-sm text-white/70">Amount Paid</p>
                          <p className="text-3xl font-bold text-green-400">
                            ₦{ticketData.ticket_price.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/10 p-6 rounded-lg">
                      <div className="flex items-center gap-4">
                        <Calendar className="h-6 w-6 text-white/70" />
                        <div>
                          <p className="text-sm text-white/70">Registration Date</p>
                          <p className="font-semibold text-white">
                            {new Date(ticketData.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Status Information */}
                <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 p-6 rounded-lg border border-blue-400/30">
                  <h3 className="font-semibold text-blue-200 mb-2">📋 Verification Status:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-blue-100">Code Valid</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-blue-100">Payment Confirmed</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-blue-100">Ready for Entry</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4 pt-6">
                  {!verified ? (
                    <>
                      <Button
                        onClick={grantEntry}
                        className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-6 text-xl"
                      >
                        ✅ GRANT ENTRY
                      </Button>
                      <Button
                        onClick={resetVerification}
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20 py-6"
                      >
                        🔄 New Search
                      </Button>
                    </>
                  ) : (
                    <Button
                      onClick={resetVerification}
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-6 text-xl"
                    >
                      🔍 Verify Next Attendee
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
