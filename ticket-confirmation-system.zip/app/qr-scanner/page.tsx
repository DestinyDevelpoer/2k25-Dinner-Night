"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { QrCode, Scan } from "lucide-react"

export default function QRScannerPage() {
  const [qrCodeData, setQrCodeData] = useState("")
  const [scannedLink, setScannedLink] = useState("")

  useEffect(() => {
    // Generate QR code data for the event
    const eventQRData = `${window.location.origin}/scan-verification`
    setQrCodeData(eventQRData)
  }, [])

  const handleScan = () => {
    if (scannedLink) {
      // In a real app, this would validate the scanned link
      window.open(scannedLink, "_blank")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* QR Code Display */}
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <QrCode className="h-6 w-6" />
                Event QR Code
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="bg-white p-8 rounded-lg shadow-inner mb-4">
                <div className="w-64 h-64 mx-auto bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center">
                  <div className="text-center">
                    <QrCode className="h-16 w-16 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-gray-600">QR Code</p>
                    <p className="text-xs text-gray-500 mt-2 break-all">{qrCodeData}</p>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-600">Attendees will scan this QR code with their verification links</p>
            </CardContent>
          </Card>

          {/* Manual Link Scanner */}
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Scan className="h-6 w-6" />
                Verify Attendee
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="verification-link">Paste Verification Link</Label>
                  <Input
                    id="verification-link"
                    type="url"
                    value={scannedLink}
                    onChange={(e) => setScannedLink(e.target.value)}
                    placeholder="https://yoursite.com/verify/..."
                  />
                </div>
                <Button onClick={handleScan} className="w-full" disabled={!scannedLink}>
                  Verify Attendee
                </Button>
              </div>

              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">How it works:</h3>
                <ol className="text-sm text-blue-700 space-y-1">
                  <li>1. Attendee opens their verification link</li>
                  <li>2. They scan this QR code with their phone</li>
                  <li>3. Their details appear for verification</li>
                  <li>4. Confirm their identity and grant entry</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
