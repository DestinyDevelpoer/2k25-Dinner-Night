"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, CheckCircle, AlertCircle, ArrowLeft, Copy, Download, Camera } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"
import { generateVerificationCode, ensureUniqueCode } from "@/lib/verification-codes"

// Primary bucket for event photos
const PRIMARY_BUCKET = "ticket-assets"
// Fallback to the built-in public bucket if the primary one is missing
const FALLBACK_BUCKET = "public"

/**
 * Attempts to upload the file to the primary bucket; if that bucket
 * doesn't exist it retries once with the fallback bucket.
 *
 * Returns the public URL or null on failure.
 */
const uploadFile = async (file: File, folder: string): Promise<string | null> => {
  const fileExt = file.name.split(".").pop()
  const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`
  const pathInBucket = `${folder}/${fileName}`

  // Helper to do the actual upload
  const tryUpload = async (bucket: string) => {
    const { error } = await supabase.storage.from(bucket).upload(pathInBucket, file, {
      cacheControl: "3600",
      upsert: false,
    })
    if (error) throw error

    const {
      data: { publicUrl },
    } = supabase.storage.from(bucket).getPublicUrl(pathInBucket)
    return publicUrl
  }

  try {
    // First attempt — event-specific bucket
    return await tryUpload(PRIMARY_BUCKET)
  } catch (err: any) {
    // If the error is “bucket not found”, retry with fallback
    if (
      String(err.message || err)
        .toLowerCase()
        .includes("bucket not found")
    ) {
      try {
        console.warn("ticket-assets bucket missing – falling back to public bucket")
        return await tryUpload(FALLBACK_BUCKET)
      } catch (fallbackErr) {
        console.error("Fallback upload failed:", fallbackErr)
        return null
      }
    }
    console.error("Upload error:", err)
    return null
  }
}

interface PaidName {
  id: string
  name: string
  amount_paid: number
  is_used: boolean
  verification_code: string
}

// Updated ticket types to handle flexible pricing
const getTicketTypeFromAmount = (amount: number) => {
  if (amount <= 3000) return { type: "regular", label: `Regular (₦${amount.toLocaleString()})` }
  if (amount === 5000) return { type: "vip", label: `VIP (₦${amount.toLocaleString()})` }
  if (amount === 10000) return { type: "vvip", label: `VVIP (₦${amount.toLocaleString()})` }
  return { type: "regular", label: `Regular (₦${amount.toLocaleString()})` }
}

// Generate barcode-like pattern
const generateBarcode = (code: string | null | undefined) => {
  if (!code) return ""

  try {
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return ""

    canvas.width = 300
    canvas.height = 100

    // White background
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Black bars
    ctx.fillStyle = "#000000"

    // Generate pattern based on verification code
    const pattern = code.split("").map((char) => char.charCodeAt(0) % 10)
    let x = 20

    pattern.forEach((num) => {
      const width = (num % 3) + 2
      const height = 60
      ctx.fillRect(x, 20, width, height)
      x += width + 2
    })

    // Add text below
    ctx.font = "12px monospace"
    ctx.textAlign = "center"
    ctx.fillText(code, canvas.width / 2, 95)

    return canvas.toDataURL()
  } catch (error) {
    console.error("Error generating barcode:", error)
    return ""
  }
}

export default function ConfirmTicketPage() {
  const [paidNames, setPaidNames] = useState<PaidName[]>([])
  const [selectedName, setSelectedName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [pictureFile, setPictureFile] = useState<File | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [verificationCode, setVerificationCode] = useState("")
  const [barcodeImage, setBarcodeImage] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [showSuccess, setShowSuccess] = useState(false)
  const [selectedNameData, setSelectedNameData] = useState<PaidName | null>(null)

  useEffect(() => {
    fetchPaidNames()
  }, [])

  const fetchPaidNames = async () => {
    setIsLoading(true)
    try {
      const { data, error } = await supabase.from("paid_names").select("*").eq("is_used", false).order("name")

      if (error) {
        console.error("Error fetching paid names:", error)
        setMessage({
          type: "error",
          text: "Unable to load available names. Please refresh the page or contact support.",
        })
      } else {
        setPaidNames(data || [])
      }
    } catch (err) {
      console.error("Network error:", err)
      setMessage({
        type: "error",
        text: "Network error. Please check your connection and try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  /**
   * Makes sure the selected name has a verification_code.
   * If absent, we create one, ensure it’s unique, store it and return it.
   */
  const ensureCodeForName = async (nameRow: PaidName) => {
    if (nameRow.verification_code && nameRow.verification_code.trim() !== "") {
      return nameRow.verification_code
    }

    // 1 – Get all current codes so we don’t collide.
    const { data: existing, error: fetchErr } = await supabase.from("paid_names").select("verification_code")

    const existingCodes = fetchErr || !existing ? [] : existing.map((r) => r.verification_code).filter(Boolean)

    // 2 – Generate & ensure uniqueness.
    const generated = generateVerificationCode(nameRow.name, nameRow.amount_paid, existingCodes.length)
    const uniqueCode = ensureUniqueCode(generated, existingCodes)

    // 3 – Save back to DB.
    await supabase.from("paid_names").update({ verification_code: uniqueCode }).eq("id", nameRow.id)

    // 4 – Update local state so UI reflects it.
    setPaidNames((prev) => prev.map((p) => (p.id === nameRow.id ? { ...p, verification_code: uniqueCode } : p)))

    return uniqueCode
  }

  const handleNameChange = (nameId: string) => {
    setSelectedName(nameId)
    const selectedData = paidNames.find((n) => n.id === nameId)
    if (selectedData) {
      setSelectedNameData(selectedData)
      setVerificationCode(selectedData.verification_code || "")
    } else {
      setSelectedNameData(null)
      setVerificationCode("")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setMessage(null)

    try {
      if (!selectedName || !selectedNameData) {
        throw new Error("Please select your name from the list")
      }

      // Ensure we have a code (generates/saves one if absent).
      const codeToUse = await ensureCodeForName(selectedNameData)

      // Upload picture if provided
      let pictureUrl = null
      if (pictureFile) {
        setMessage({ type: "success", text: "Uploading picture..." })
        pictureUrl = await uploadFile(pictureFile, "pictures")
        if (!pictureUrl) {
          console.warn("Picture upload failed, continuing without picture")
        }
      }

      // Generate unique verification link using the verification code
      const newVerificationLink = `${window.location.origin}/verify/${codeToUse}`

      // Get ticket type from amount
      const ticketInfo = getTicketTypeFromAmount(selectedNameData.amount_paid)

      // Save to database
      setMessage({ type: "success", text: "Saving ticket information..." })
      const { error: insertError } = await supabase.from("tickets").insert({
        name: selectedNameData.name,
        email,
        phone,
        ticket_type: ticketInfo.type as "regular" | "vip" | "vvip",
        ticket_price: selectedNameData.amount_paid,
        picture_url: pictureUrl,
        verification_link: newVerificationLink,
        verification_code: codeToUse,
        status: "confirmed",
      })

      if (insertError) {
        throw new Error("Failed to save ticket information. Please try again.")
      }

      // Mark name as used
      await supabase.from("paid_names").update({ is_used: true }).eq("id", selectedName)

      // Generate barcode safely
      const barcode = generateBarcode(codeToUse)
      if (barcode) {
        setBarcodeImage(barcode)
      }

      setShowSuccess(true)
      setMessage({
        type: "success",
        text: "🎉 Ticket confirmed successfully! Your unique verification code is ready for entry.",
      })

      // Reset form
      setSelectedName("")
      setSelectedNameData(null)
      setEmail("")
      setPhone("")
      setPictureFile(null)
      fetchPaidNames() // Refresh available names
      setVerificationCode(codeToUse)
    } catch (error) {
      console.error("Form submission error:", error)
      setMessage({
        type: "error",
        text: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("Copied to clipboard!")
  }

  const downloadBarcode = () => {
    if (!barcodeImage) return
    const link = document.createElement("a")
    link.download = `ticket-barcode-${verificationCode}.png`
    link.href = barcodeImage
    link.click()
  }

  const resetForm = () => {
    setShowSuccess(false)
    setVerificationCode("")
    setBarcodeImage("")
    setMessage(null)
    setSelectedNameData(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 py-8 px-4">
      {/* Header */}
      <header className="mb-8">
        <div className="max-w-2xl mx-auto flex justify-between items-center text-white">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="text-right">
            <p className="text-sm opacity-80">Event:</p>
            <p className="font-semibold">2K25 Dinner Party</p>
            <p className="text-xs opacity-70">June 21, 2025</p>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto">
        {!showSuccess ? (
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="text-center bg-gradient-to-r from-yellow-400/20 to-pink-500/20">
              <CardTitle className="text-2xl font-bold text-white">Confirm Your Ticket</CardTitle>
              <CardDescription className="text-white/80">
                Complete the form below to generate your entry verification
              </CardDescription>
            </CardHeader>

            <CardContent className="p-8">
              {isLoading && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-400 mx-auto mb-4"></div>
                  <p className="text-white">Loading available names...</p>
                </div>
              )}

              {!isLoading && (
                <>
                  <div className="mb-6 p-4 bg-blue-500/20 border border-blue-400/30 rounded-lg">
                    <h3 className="font-semibold text-blue-200 mb-2">📋 Instructions:</h3>
                    <ul className="text-sm text-blue-100 space-y-1">
                      <li>• Find and select your name from the list</li>
                      <li>• Upload a clear photo of yourself (recommended)</li>
                      <li>• Provide your contact information</li>
                      <li>• Get your unique verification code for entry</li>
                    </ul>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">
                        Select Your Name *
                      </Label>
                      <Select value={selectedName} onValueChange={handleNameChange}>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue placeholder="Choose your name from the paid list" />
                        </SelectTrigger>
                        <SelectContent>
                          {paidNames.map((name) => (
                            <SelectItem key={name.id} value={name.id}>
                              {name.name} - ₦{name.amount_paid.toLocaleString()} - Code: {name.verification_code}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedNameData && (
                      <div className="p-4 bg-green-500/20 border border-green-400/30 rounded-lg">
                        <h3 className="font-semibold text-green-200 mb-2">✅ Your Ticket Details:</h3>
                        <div className="text-sm text-green-100 space-y-1">
                          <p>
                            <strong>Name:</strong> {selectedNameData.name}
                          </p>
                          <p>
                            <strong>Amount Paid:</strong> ₦{selectedNameData.amount_paid.toLocaleString()}
                          </p>
                          <p>
                            <strong>Ticket Type:</strong> {getTicketTypeFromAmount(selectedNameData.amount_paid).label}
                          </p>
                          <p>
                            <strong>Your Unique Code:</strong>{" "}
                            <span className="font-mono bg-white/20 px-2 py-1 rounded text-yellow-200 font-bold">
                              {selectedNameData.verification_code}
                            </span>
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="your.email@example.com"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-white">
                          Phone Number
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+234 xxx xxx xxxx"
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="picture" className="text-white">
                        Upload Your Picture (Recommended)
                      </Label>
                      <div className="border-2 border-dashed border-white/30 rounded-lg p-6 text-center hover:border-white/50 transition-colors bg-white/5">
                        <input
                          id="picture"
                          type="file"
                          accept="image/*"
                          onChange={(e) => setPictureFile(e.target.files?.[0] || null)}
                          className="hidden"
                        />
                        <label htmlFor="picture" className="cursor-pointer">
                          <Upload className="mx-auto h-12 w-12 text-white/60" />
                          <p className="mt-2 text-sm text-white/80">
                            {pictureFile ? `✅ ${pictureFile.name}` : "Click to upload your picture"}
                          </p>
                          <p className="text-xs text-white/60 mt-1">
                            This helps with verification at the event entrance
                          </p>
                        </label>
                      </div>
                    </div>

                    {message && (
                      <Alert
                        className={
                          message.type === "error"
                            ? "border-red-400/50 bg-red-500/20"
                            : "border-green-400/50 bg-green-500/20"
                        }
                      >
                        {message.type === "error" ? (
                          <AlertCircle className="h-4 w-4 text-red-400" />
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-400" />
                        )}
                        <AlertDescription className={message.type === "error" ? "text-red-200" : "text-green-200"}>
                          {message.text}
                        </AlertDescription>
                      </Alert>
                    )}

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-yellow-400 to-pink-500 hover:from-yellow-500 hover:to-pink-600 text-black font-bold py-3"
                      disabled={isSubmitting || !selectedName}
                    >
                      {isSubmitting ? "Processing..." : "🎫 Confirm My Ticket"}
                    </Button>
                  </form>
                </>
              )}
            </CardContent>
          </Card>
        ) : (
          // Success Screen
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="text-center bg-gradient-to-r from-green-500/20 to-blue-500/20">
              <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-4" />
              <CardTitle className="text-3xl font-bold text-white">🎉 TICKET CONFIRMED!</CardTitle>
              <CardDescription className="text-white/80 text-lg">Your entry verification is ready</CardDescription>
            </CardHeader>

            <CardContent className="p-8">
              <div className="space-y-6">
                {/* Verification Code Display */}
                <div className="text-center bg-gradient-to-r from-yellow-500/20 to-pink-500/20 p-6 rounded-lg border border-yellow-400/30">
                  <h3 className="font-bold text-yellow-200 text-xl mb-4">🔑 Your Unique Entry Code</h3>
                  <div className="bg-black/30 p-4 rounded-lg mb-4">
                    <div className="text-4xl font-bold font-mono text-yellow-300 bg-black/50 px-6 py-4 rounded border">
                      {verificationCode}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(verificationCode)}
                      variant="outline"
                      className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy Code
                    </Button>
                  </div>
                </div>

                {/* Barcode Display */}
                {barcodeImage && (
                  <div className="bg-white/10 p-6 rounded-lg">
                    <h3 className="font-semibold text-white mb-4 text-center">📊 Your Entry Barcode</h3>
                    <div className="bg-white p-4 rounded-lg text-center">
                      <img src={barcodeImage || "/placeholder.svg"} alt="Verification Barcode" className="mx-auto" />
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button
                        onClick={downloadBarcode}
                        variant="outline"
                        className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      <Button
                        onClick={() => {
                          alert("Please take a screenshot of this screen for entry verification!")
                        }}
                        variant="outline"
                        className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
                      >
                        <Camera className="h-4 w-4 mr-2" />
                        Screenshot
                      </Button>
                    </div>
                  </div>
                )}

                {/* Instructions */}
                <div className="bg-blue-500/20 border border-blue-400/30 p-4 rounded-lg">
                  <h3 className="font-semibold text-blue-200 mb-2">📝 Important Instructions:</h3>
                  <ul className="text-sm text-blue-100 space-y-1">
                    <li>
                      ✅ Save your verification code: <strong>{verificationCode}</strong>
                    </li>
                    <li>✅ Take a screenshot of this page</li>
                    <li>✅ Show your code to admin at event entrance</li>
                    <li>✅ Admin will verify your details and grant entry</li>
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={resetForm}
                    variant="outline"
                    className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    Confirm Another Ticket
                  </Button>
                  <Link href="/" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700">
                      Back to Home
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
