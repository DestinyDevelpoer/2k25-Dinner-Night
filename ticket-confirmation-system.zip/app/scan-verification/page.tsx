"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Mail, Phone, Ticket, ArrowLeft } from "lucide-react"
import { supabase } from "@/lib/supabase"

interface TicketData {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: "regular" | "vip" | "vvip"
  ticket_price: number
  picture_url: string | null
  status: string
  created_at: string
}

export default function ScanVerificationPage() {
  const searchParams = useSearchParams()
  const [ticketData, setTicketData] = useState<TicketData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const ticketId = searchParams.get("ticket")
    if (ticketId) {
      fetchTicketByVerificationId(ticketId)
    } else {
      setError("No ticket information provided")
      setLoading(false)
    }
  }, [searchParams])

  const fetchTicketByVerificationId = async (verificationId: string) => {
    try {
      const verificationLink = `${window.location.origin}/verify/${verificationId}`

      const { data, error } = await supabase
        .from("tickets")
        .select("*")
        .eq("verification_link", verificationLink)
        .single()

      if (error) {
        setError("Ticket not found or invalid")
      } else {
        setTicketData(data)
      }
    } catch (err) {
      setError("Failed to verify ticket")
    } finally {
      setLoading(false)
    }
  }

  const getTicketTypeColor = (type: string) => {
    switch (type) {
      case "regular":
        return "bg-blue-100 text-blue-800"
      case "vip":
        return "bg-purple-100 text-purple-800"
      case "vvip":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Verifying ticket...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error || !ticketData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-red-500 mb-4">
              <CheckCircle className="h-16 w-16 mx-auto" />
            </div>
            <h2 className="text-xl font-bold text-red-800 mb-2">Verification Failed</h2>
            <p className="text-red-600 mb-4">{error}</p>
            <Button onClick={() => window.history.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader className="text-center bg-green-500 text-white rounded-t-lg">
            <div className="flex items-center justify-center mb-4">
              <CheckCircle className="h-20 w-20" />
            </div>
            <CardTitle className="text-3xl font-bold">✅ VERIFIED ATTENDEE</CardTitle>
            <p className="text-green-100 text-lg">Entry Approved</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Profile Picture */}
              {ticketData.picture_url && (
                <div className="text-center">
                  <img
                    src={ticketData.picture_url || "/placeholder.svg"}
                    alt="Profile"
                    className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-green-300"
                  />
                </div>
              )}

              {/* Personal Information */}
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{ticketData.name}</h2>
                <Badge className={`${getTicketTypeColor(ticketData.ticket_type)} text-lg px-4 py-2`}>
                  {ticketData.ticket_type.toUpperCase()} TICKET
                </Badge>
              </div>

              {/* Contact Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
                {ticketData.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold">{ticketData.email}</p>
                    </div>
                  </div>
                )}

                {ticketData.phone && (
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-semibold">{ticketData.phone}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Information */}
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Ticket className="h-6 w-6 text-green-600" />
                    <div>
                      <p className="text-sm text-green-700">Payment Status</p>
                      <p className="font-bold text-green-800">CONFIRMED</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-700">Amount Paid</p>
                    <p className="text-2xl font-bold text-green-800">₦{ticketData.ticket_price.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button onClick={() => window.history.back()} variant="outline" className="flex-1">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Scanner
                </Button>
                <Button onClick={() => window.location.reload()} className="flex-1 bg-green-600 hover:bg-green-700">
                  Scan Another
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
