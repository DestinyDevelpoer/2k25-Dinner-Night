import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Ticket, QrCode, Shield, Users, CheckCircle, Calendar, MapPin, Clock, MessageCircle } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] opacity-10"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/50 via-blue-900/50 to-indigo-900/50"></div>

      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-400/20 rounded-full blur-xl animate-pulse"></div>
      <div className="absolute top-40 right-20 w-32 h-32 bg-pink-400/20 rounded-full blur-xl animate-pulse delay-1000"></div>
      <div className="absolute bottom-20 left-20 w-24 h-24 bg-blue-400/20 rounded-full blur-xl animate-pulse delay-2000"></div>

      {/* Header */}
      <header className="relative z-10 p-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="text-white">
            <h1 className="text-2xl font-bold">🎫 Ticket System</h1>
          </div>
          <div className="text-right text-white">
            <p className="text-sm opacity-80">Event:</p>
            <p className="font-semibold">2K25 Dinner Party</p>
          </div>
        </div>
      </header>

      <div className="relative z-10 container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="mb-8">
            <h1 className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 mb-4 animate-pulse">
              2K25
            </h1>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">DINNER PARTY</h2>
            <div className="flex items-center justify-center gap-2 text-yellow-400 text-xl font-semibold mb-6">
              <span className="w-12 h-0.5 bg-yellow-400"></span>
              <span>ORGANISED BY THE LEADING EDGE OF MUI</span>
              <span className="w-12 h-0.5 bg-yellow-400"></span>
            </div>
          </div>

          {/* Event Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 text-white">
              <Calendar className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Date</h3>
              <p className="text-sm opacity-80">June 21, 2025</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 text-white">
              <Clock className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Schedule</h3>
              <p className="text-sm opacity-80">7:00 PM - 9:00 PM: Dinner Party</p>
              <p className="text-xs opacity-70">9:30 PM - 12:00 AM: Dance & After Party</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-lg p-6 text-white">
              <MapPin className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Venue</h3>
              <p className="text-sm opacity-80">Mudiame University</p>
              <p className="text-xs opacity-70">Irrua Campus</p>
            </div>
          </div>

          {/* Main CTA */}
          <div className="mb-12">
            <Link href="/confirm-ticket">
              <Button
                size="lg"
                className="text-xl px-12 py-6 bg-gradient-to-r from-yellow-400 to-pink-500 hover:from-yellow-500 hover:to-pink-600 text-black font-bold rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                🎉 CONFIRM YOUR TICKET NOW
              </Button>
            </Link>
            <p className="text-white/80 mt-4">Join us for an unforgettable evening!</p>
          </div>
        </div>

        {/* Ticket Types */}
        <div className="mb-16 max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-white">Ticket Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-white/10 backdrop-blur-lg border-blue-400/30 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <CardHeader className="text-center bg-gradient-to-br from-blue-500/20 to-blue-600/20">
                <CardTitle className="text-blue-300 text-2xl">Regular</CardTitle>
                <CardDescription className="text-3xl font-bold text-blue-200">₦2,000 - ₦3,000</CardDescription>
              </CardHeader>
              <CardContent className="p-6 text-white">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-blue-400" />
                    <span>General admission</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-blue-400" />
                    <span>Welcome drink</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-blue-400" />
                    <span>Dinner & entertainment</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-lg border-purple-400/30 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <CardHeader className="text-center bg-gradient-to-br from-purple-500/20 to-purple-600/20">
                <CardTitle className="text-purple-300 text-2xl">VIP</CardTitle>
                <CardDescription className="text-3xl font-bold text-purple-200">₦5,000</CardDescription>
              </CardHeader>
              <CardContent className="p-6 text-white">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-purple-400" />
                    <span>Priority seating</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-purple-400" />
                    <span>VIP lounge access</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-purple-400" />
                    <span>Premium dinner & drinks</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-purple-400" />
                    <span>Meet & greet session</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-lg border-yellow-400/30 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
              <CardHeader className="text-center bg-gradient-to-br from-yellow-500/20 to-yellow-600/20">
                <CardTitle className="text-yellow-300 text-2xl">VVIP</CardTitle>
                <CardDescription className="text-3xl font-bold text-yellow-200">₦10,000</CardDescription>
              </CardHeader>
              <CardContent className="p-6 text-white">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-yellow-400" />
                    <span>Front row premium seats</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-yellow-400" />
                    <span>Exclusive VVIP lounge</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-yellow-400" />
                    <span>Gourmet dining experience</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-yellow-400" />
                    <span>Private photo session</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-yellow-400" />
                    <span>Exclusive gift package</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Navigation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
            <CardHeader className="text-center">
              <Ticket className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
              <CardTitle className="text-white">Confirm Ticket</CardTitle>
              <CardDescription className="text-white/70">Submit your ticket confirmation</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/confirm-ticket">
                <Button className="w-full bg-gradient-to-r from-yellow-400 to-pink-500 hover:from-yellow-500 hover:to-pink-600 text-black font-semibold">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
            <CardHeader className="text-center">
              <QrCode className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <CardTitle className="text-white">QR Scanner</CardTitle>
              <CardDescription className="text-white/70">Event verification system</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/qr-scanner">
                <Button className="w-full" variant="outline">
                  Open Scanner
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
            <CardHeader className="text-center">
              <Shield className="h-12 w-12 text-green-400 mx-auto mb-4" />
              <CardTitle className="text-white">Admin Panel</CardTitle>
              <CardDescription className="text-white/70">Secure admin access</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/admin/login">
                <Button className="w-full" variant="outline">
                  Admin Login
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
            <CardHeader className="text-center">
              <MessageCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
              <CardTitle className="text-white">Support</CardTitle>
              <CardDescription className="text-white/70">Need assistance?</CardDescription>
            </CardHeader>
            <CardContent>
              <a href="https://wa.me/2349068754630" target="_blank" rel="noopener noreferrer" className="block w-full">
                <Button className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  WhatsApp Support
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>

        {/* Support Information */}
        <div className="mt-16 max-w-4xl mx-auto">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="text-center">
              <CardTitle className="text-white text-2xl">Need Help?</CardTitle>
              <CardDescription className="text-white/70">
                Our support team is available to assist you with any questions
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/5 p-6 rounded-lg">
                  <MessageCircle className="h-8 w-8 text-green-400 mx-auto mb-3" />
                  <h3 className="font-semibold text-white mb-2">WhatsApp Support</h3>
                  <p className="text-white/70 text-sm mb-4">Get instant help via WhatsApp</p>
                  <a href="https://wa.me/2349068754630" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-green-500 hover:bg-green-600 text-white">Chat Now</Button>
                  </a>
                </div>
                <div className="bg-white/5 p-6 rounded-lg">
                  <Users className="h-8 w-8 text-blue-400 mx-auto mb-3" />
                  <h3 className="font-semibold text-white mb-2">Event Information</h3>
                  <p className="text-white/70 text-sm mb-4">Questions about the event details</p>
                  <a
                    href="https://wa.me/2349068754630?text=Hi, I need help with event information"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                      Ask Questions
                    </Button>
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
