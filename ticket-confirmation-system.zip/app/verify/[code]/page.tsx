"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, User, Mail, Phone, Ticket, Calendar, Copy, Share2, ArrowLeft } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

interface TicketData {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: "regular" | "vip" | "vvip"
  ticket_price: number
  picture_url: string | null
  verification_code: string
  status: string
  created_at: string
}

interface PaidNameData {
  id: string
  name: string
  amount_paid: number
  verification_code: string
  is_used: boolean
  created_at: string
}

export default function VerifyPage() {
  const params = useParams()
  const [ticketData, setTicketData] = useState<TicketData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    if (params.code) {
      fetchTicketData()
    }
  }, [params.code])

  const fetchTicketData = async () => {
    try {
      const verificationCode = params.code as string

      // First try to find in tickets table
      const { data: ticketResult, error: ticketError } = await supabase
        .from("tickets")
        .select("*")
        .eq("verification_code", verificationCode)
        .single()

      if (ticketResult) {
        setTicketData(ticketResult)
      } else {
        // If not found in tickets, check paid_names table
        const { data: nameResult, error: nameError } = await supabase
          .from("paid_names")
          .select("*")
          .eq("verification_code", verificationCode)
          .single()

        if (nameResult) {
          // Convert paid_name data to ticket format for display
          const mockTicketData: TicketData = {
            id: nameResult.id,
            name: nameResult.name,
            email: null,
            phone: null,
            ticket_type: nameResult.amount_paid <= 3000 ? "regular" : nameResult.amount_paid === 5000 ? "vip" : "vvip",
            ticket_price: nameResult.amount_paid,
            picture_url: null,
            verification_code: nameResult.verification_code,
            status: nameResult.is_used ? "used" : "valid",
            created_at: nameResult.created_at,
          }
          setTicketData(mockTicketData)
        } else {
          setError("Verification code not found. Please check the code and try again.")
        }
      }
    } catch (err) {
      console.error("Error fetching ticket data:", err)
      setError("Failed to load ticket information. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const getTicketTypeColor = (type: string) => {
    switch (type) {
      case "regular":
        return "bg-blue-100 text-blue-800"
      case "vip":
        return "bg-purple-100 text-purple-800"
      case "vvip":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const shareTicket = async () => {
    const shareData = {
      title: `${ticketData?.name}'s Event Ticket`,
      text: `Verified ticket for ${ticketData?.name} - ${ticketData?.ticket_type.toUpperCase()} (₦${ticketData?.ticket_price.toLocaleString()})`,
      url: window.location.href,
    }

    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch (err) {
        console.log("Error sharing:", err)
      }
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert("Link copied to clipboard!")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading ticket information...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error || !ticketData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-red-500 mb-4">
              <CheckCircle className="h-16 w-16 mx-auto" />
            </div>
            <h2 className="text-xl font-bold text-red-800 mb-2">Verification Failed</h2>
            <p className="text-red-600 mb-4">{error}</p>
            <div className="flex gap-2">
              <Link href="/" className="flex-1">
                <Button variant="outline" className="w-full">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Go Home
                </Button>
              </Link>
              <Link href="/confirm-ticket" className="flex-1">
                <Button className="w-full">Confirm Ticket</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="mb-6">
          <CardHeader className="text-center bg-green-500 text-white rounded-t-lg">
            <div className="flex items-center justify-center mb-4">
              <CheckCircle className="h-16 w-16" />
            </div>
            <CardTitle className="text-2xl font-bold">PAYMENT CONFIRMED</CardTitle>
            <p className="text-green-100">Ticket verification successful</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Profile Picture */}
              {ticketData.picture_url && (
                <div className="text-center">
                  <img
                    src={ticketData.picture_url || "/placeholder.svg"}
                    alt="Profile"
                    className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-green-200"
                  />
                </div>
              )}

              {/* Verification Code Display */}
              <div className="text-center bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Verification Code</p>
                <div className="text-2xl font-bold font-mono text-gray-900 bg-white px-4 py-2 rounded border">
                  {ticketData.verification_code}
                </div>
              </div>

              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <User className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-600">Name</p>
                    <p className="font-semibold">{ticketData.name}</p>
                  </div>
                </div>

                {ticketData.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold">{ticketData.email}</p>
                    </div>
                  </div>
                )}

                {ticketData.phone && (
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-semibold">{ticketData.phone}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-600">Registered</p>
                    <p className="font-semibold">{new Date(ticketData.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>

              {/* Ticket Information */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Ticket className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Ticket Type</p>
                      <Badge className={getTicketTypeColor(ticketData.ticket_type)}>
                        {ticketData.ticket_type.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Amount Paid</p>
                    <p className="text-xl font-bold text-green-600">₦{ticketData.ticket_price.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={() => navigator.clipboard.writeText(ticketData.verification_code)}
                  variant="outline"
                  className="flex-1"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Code
                </Button>
                <Button onClick={shareTicket} className="flex-1 bg-green-600 hover:bg-green-700">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share Ticket
                </Button>
              </div>

              {/* Support Information */}
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">Need Help?</h3>
                <p className="text-sm text-blue-700 mb-3">Contact our support team for assistance</p>
                <a href="https://wa.me/2349068754630" target="_blank" rel="noopener noreferrer">
                  <Button className="w-full bg-green-500 hover:bg-green-600 text-white">WhatsApp Support</Button>
                </a>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
