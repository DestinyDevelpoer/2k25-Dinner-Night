"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, User, Mail, Phone, Ticket, Calendar } from "lucide-react"
import { supabase } from "@/lib/supabase"

interface TicketData {
  id: string
  name: string
  email: string | null
  phone: string | null
  ticket_type: "regular" | "vip" | "vvip"
  ticket_price: number
  picture_url: string | null
  status: string
  created_at: string
}

export default function VerifyPage() {
  const params = useParams()
  const [ticketData, setTicketData] = useState<TicketData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [canScan, setCanScan] = useState(false)

  useEffect(() => {
    if (params.id) {
      fetchTicketData()
      checkScanCapability()
    }
  }, [params.id])

  const fetchTicketData = async () => {
    try {
      const verificationLink = `${window.location.origin}/verify/${params.id}`

      const { data, error } = await supabase
        .from("tickets")
        .select("*")
        .eq("verification_link", verificationLink)
        .single()

      if (error) {
        setError("Ticket not found or invalid verification link")
      } else {
        setTicketData(data)
      }
    } catch (err) {
      setError("Failed to load ticket information")
    } finally {
      setLoading(false)
    }
  }

  const checkScanCapability = () => {
    // Check if device has camera for QR scanning
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      setCanScan(true)
    }
  }

  const handleScanQR = async () => {
    try {
      // In a real implementation, you would use a QR scanner library
      // For demo, we'll simulate scanning the event QR code
      const eventQRUrl = `${window.location.origin}/scan-verification`

      // Simulate QR scan success
      window.location.href = `${eventQRUrl}?ticket=${params.id}`
    } catch (error) {
      console.error("QR scan error:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading ticket information...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error || !ticketData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-red-500 mb-4">
              <CheckCircle className="h-16 w-16 mx-auto" />
            </div>
            <h2 className="text-xl font-bold text-red-800 mb-2">Verification Failed</h2>
            <p className="text-red-600">{error}</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const getTicketTypeColor = (type: string) => {
    switch (type) {
      case "regular":
        return "bg-blue-100 text-blue-800"
      case "vip":
        return "bg-purple-100 text-purple-800"
      case "vvip":
        return "bg-gold-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="mb-6">
          <CardHeader className="text-center bg-green-500 text-white rounded-t-lg">
            <div className="flex items-center justify-center mb-4">
              <CheckCircle className="h-16 w-16" />
            </div>
            <CardTitle className="text-2xl font-bold">PAYMENT CONFIRMED</CardTitle>
            <p className="text-green-100">Ticket verification successful</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Profile Picture */}
              {ticketData.picture_url && (
                <div className="text-center">
                  <img
                    src={ticketData.picture_url || "/placeholder.svg"}
                    alt="Profile"
                    className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-green-200"
                  />
                </div>
              )}

              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <User className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-600">Name</p>
                    <p className="font-semibold">{ticketData.name}</p>
                  </div>
                </div>

                {ticketData.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold">{ticketData.email}</p>
                    </div>
                  </div>
                )}

                {ticketData.phone && (
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Phone</p>
                      <p className="font-semibold">{ticketData.phone}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-600">Registered</p>
                    <p className="font-semibold">{new Date(ticketData.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>

              {/* Ticket Information */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Ticket className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Ticket Type</p>
                      <Badge className={getTicketTypeColor(ticketData.ticket_type)}>
                        {ticketData.ticket_type.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Amount Paid</p>
                    <p className="text-xl font-bold text-green-600">₦{ticketData.ticket_price.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* QR Scanner Button */}
              <div className="text-center">
                <Button
                  onClick={handleScanQR}
                  size="lg"
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={!canScan}
                >
                  {canScan ? "Scan Event QR Code" : "QR Scanner Not Available"}
                </Button>
                <p className="text-sm text-gray-600 mt-2">Use this to scan the QR code at the event entrance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
